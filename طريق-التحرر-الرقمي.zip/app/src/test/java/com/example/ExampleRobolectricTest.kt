package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ChapterEntity
import com.example.data.local.ChapterJsonConverter
import com.example.data.model.ChapterSection
import com.example.data.repository.BookRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("طريق التحرر", appName)
    }

    @Test
    fun `verify book chapters are loaded`() {
        assertTrue(BookRepository.allChapters.isNotEmpty())
        assertEquals(13, BookRepository.allChapters.size)
    }

    @Test
    fun `verify ChapterJsonConverter roundtrip`() {
        val originalSections = listOf(
            ChapterSection(
                id = "sec_1",
                title = "المبحث التجريبي",
                paragraphs = listOf("فقرة أولى عن التعافي", "فقرة ثانية عن اليقين"),
                quranOrHadith = listOf("وَالَّذِينَ جَاهَدُوا فِينَا لَنَهْدِيَنَّهُمْ سُبُلَنَا"),
                scientificNote = "إعادة تشكيل المستقبلات الدوبامينية في النواة المتكئة",
                keyTakeaway = "أنت سيد قرارك ولست عبداً لشهوة عابرة"
            )
        )

        val json = ChapterJsonConverter.sectionsToJson(originalSections)
        assertTrue(json.contains("المبحث التجريبي"))

        val restored = ChapterJsonConverter.jsonToSections(json)
        assertEquals(1, restored.size)
        assertEquals("المبحث التجريبي", restored[0].title)
        assertEquals(2, restored[0].paragraphs.size)
        assertEquals("إعادة تشكيل المستقبلات الدوبامينية في النواة المتكئة", restored[0].scientificNote)
    }

    @Test
    fun `verify Room database persistence for chapters`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.recoveryDao()

        val sampleChapter = ChapterEntity(
            id = 99,
            numberTitle = "الفصل الإضافي",
            title = "فصل مضاف عبر لوحة المشرف",
            subtitle = "عنوان فرعي تجريبي",
            summary = "ملخص الفصل",
            sectionsJson = "[]"
        )

        dao.upsertChapter(sampleChapter)
        val count = dao.getChaptersCount()
        assertEquals(1, count)

        val retrieved = dao.getChapterById(99)
        assertNotNull(retrieved)
        assertEquals("فصل مضاف عبر لوحة المشرف", retrieved?.title)

        dao.deleteChapterById(99)
        assertEquals(0, dao.getChaptersCount())

        db.close()
    }
}
