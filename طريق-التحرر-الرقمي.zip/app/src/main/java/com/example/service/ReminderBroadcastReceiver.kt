package com.example.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import java.util.Calendar

class ReminderBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(EXTRA_REMINDER_TYPE) ?: TYPE_MOTIVATIONAL
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "طريق التحرر"
        val message = intent.getStringExtra(EXTRA_MESSAGE) ?: "لن تهزمني بعد اليوم! استمر في الثبات."

        showNotification(context, title, message, type)

        // Reschedule daily alarms
        if (type == TYPE_MORNING || type == TYPE_EVENING || type == TYPE_LATE_NIGHT) {
            ReminderScheduler.scheduleNextDailyAlarm(context, type)
        }
    }

    private fun showNotification(
        context: Context,
        title: String,
        message: String,
        type: String
    ) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تنبيهات طريق التحرر الذكية",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تحفيزية، وقائية، وتذكيرات برنامج الـ 40 يوماً"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Tap opens app
        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_NAV_TARGET", type)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            type.hashCode(),
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = when (type) {
            TYPE_MORNING -> 1001
            TYPE_EVENING -> 1002
            TYPE_LATE_NIGHT -> 1003
            TYPE_MOTIVATIONAL -> 1004
            else -> 1000
        }

        notificationManager.notify(notificationId, notification)
    }

    companion object {
        const val CHANNEL_ID = "tariq_altaharrur_reminders_channel"
        const val EXTRA_REMINDER_TYPE = "reminder_type"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_MESSAGE = "extra_message"

        const val TYPE_MORNING = "MORNING"
        const val TYPE_EVENING = "EVENING"
        const val TYPE_LATE_NIGHT = "LATE_NIGHT"
        const val TYPE_MOTIVATIONAL = "MOTIVATIONAL"
    }
}

object ReminderScheduler {

    private val motivationalQuotes = listOf(
        "«لَنْ تَهْزِمَنِي بَعْدَ الْيَوْم!» — قوتك اليوم قرار يتجدد مع كل نفس.",
        "تذكر: اللذة الوهمية تمضي في دقائق، لكن وخز الضمير وألم الهزيمة يدوم أياماً. العفة عز لا يفنى.",
        "«وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا» — كل إغلاق لشاشة الفتنة يفتح في قلبك نوراً وسكينة.",
        "دماغك الآن يتعافى ويعيد بناء مسارات الدوبامين الطبيعية؛ أنت أقوى من مجرد ومضة شاشة!",
        "أنت حر.. لست عبداً لشهوتك لأنك عبد لله وحده. ارفع رأسك وأكمل يومك منتصراً.",
        "المعركة تحسم في الثواني الخمس الأولى: اهرب فوراً، غيّر مكانك، وتوضأ وصلِّ ركعتين.",
        "استحضر وقوفك أمام الله في ميثاق العهد: عاهدت الله ألا تذل نفسك، فأوفِ بعهدك.",
        "الانتصار ليس بعدم ورود الخاطر، بل بعدم الاسترسال معه وطرده كعدو باغت دارك."
    )

    fun scheduleAllReminders(
        context: Context,
        morningEnabled: Boolean = true,
        eveningEnabled: Boolean = true,
        lateNightEnabled: Boolean = true
    ) {
        if (morningEnabled) {
            scheduleDaily(
                context = context,
                type = ReminderBroadcastReceiver.TYPE_MORNING,
                hour = 7,
                minute = 0,
                title = "☀️ صباح النصر والتحرر (برنامج الـ 40 يوماً)",
                message = "ابدأ يومك بورد الصباح، دوش بارد، ونية صادقة: 'اليوم يوم انتصار جديد'."
            )
        } else {
            cancelReminder(context, ReminderBroadcastReceiver.TYPE_MORNING)
        }

        if (eveningEnabled) {
            scheduleDaily(
                context = context,
                type = ReminderBroadcastReceiver.TYPE_EVENING,
                hour = 20,
                minute = 30,
                title = "🌙 المساء الهادئ والتقييم اليومي",
                message = "سجل إنجازات اليوم في برنامج الـ 40 يوماً، واقرأ توكيدات عقلك الباطن قبل النوم."
            )
        } else {
            cancelReminder(context, ReminderBroadcastReceiver.TYPE_EVENING)
        }

        if (lateNightEnabled) {
            scheduleDaily(
                context = context,
                type = ReminderBroadcastReceiver.TYPE_LATE_NIGHT,
                hour = 23,
                minute = 30,
                title = "🛡️ حارس الليل الوقائي: انتبه!",
                message = "وقت الليل والوحدة منطقة خطر عالية! أغلق الجوال واقرأ أذكار النوم. لن تهزمني بعد اليوم!"
            )
        } else {
            cancelReminder(context, ReminderBroadcastReceiver.TYPE_LATE_NIGHT)
        }
    }

    private fun scheduleDaily(
        context: Context,
        type: String,
        hour: Int,
        minute: Int,
        title: String,
        message: String
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ReminderBroadcastReceiver::class.java).apply {
            putExtra(ReminderBroadcastReceiver.EXTRA_REMINDER_TYPE, type)
            putExtra(ReminderBroadcastReceiver.EXTRA_TITLE, title)
            putExtra(ReminderBroadcastReceiver.EXTRA_MESSAGE, message)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            type.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        } catch (_: SecurityException) {
            // Handled gracefully if exact alarm not granted
        }
    }

    fun scheduleNextDailyAlarm(context: Context, type: String) {
        when (type) {
            ReminderBroadcastReceiver.TYPE_MORNING -> scheduleDaily(
                context, type, 7, 0,
                "☀️ صباح النصر والتحرر (برنامج الـ 40 يوماً)",
                "ابدأ يومك بورد الصباح، دوش بارد، ونية صادقة: 'اليوم يوم انتصار جديد'."
            )
            ReminderBroadcastReceiver.TYPE_EVENING -> scheduleDaily(
                context, type, 20, 30,
                "🌙 المساء الهادئ والتقييم اليومي",
                "سجل إنجازات اليوم في برنامج الـ 40 يوماً، واقرأ توكيدات عقلك الباطن قبل النوم."
            )
            ReminderBroadcastReceiver.TYPE_LATE_NIGHT -> scheduleDaily(
                context, type, 23, 30,
                "🛡️ حارس الليل الوقائي: انتبه!",
                "وقت الليل والوحدة منطقة خطر عالية! أغلق الجوال واقرأ أذكار النوم. لن تهزمني بعد اليوم!"
            )
        }
    }

    fun triggerInstantMotivationalNotification(context: Context) {
        val randomQuote = motivationalQuotes.random()
        val intent = Intent(context, ReminderBroadcastReceiver::class.java).apply {
            putExtra(ReminderBroadcastReceiver.EXTRA_REMINDER_TYPE, ReminderBroadcastReceiver.TYPE_MOTIVATIONAL)
            putExtra(ReminderBroadcastReceiver.EXTRA_TITLE, "⚡ دفعة صمود مستوحاة من الكتاب")
            putExtra(ReminderBroadcastReceiver.EXTRA_MESSAGE, randomQuote)
        }
        context.sendBroadcast(intent)
    }

    fun cancelReminder(context: Context, type: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ReminderBroadcastReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            type.hashCode(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }

    fun cancelAll(context: Context) {
        cancelReminder(context, ReminderBroadcastReceiver.TYPE_MORNING)
        cancelReminder(context, ReminderBroadcastReceiver.TYPE_EVENING)
        cancelReminder(context, ReminderBroadcastReceiver.TYPE_LATE_NIGHT)
    }
}
