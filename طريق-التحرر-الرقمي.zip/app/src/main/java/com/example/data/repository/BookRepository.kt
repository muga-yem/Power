package com.example.data.repository

import android.content.Context
import com.example.data.model.BookChapter
import com.example.data.model.ChapterSection
import org.json.JSONObject

object BookRepository {
    private val defaultChapters: List<BookChapter> = listOf(
        BookContentPart1.introChapter,
        BookContentPart1.chapter1,
        BookContentPart1.chapter2,
        BookContentPart1.chapter3,
        BookContentPart1.chapter4,
        BookContentPart2.chapter5,
        BookContentPart2.chapter6,
        BookContentPart2.chapter7,
        BookContentPart2.chapter8,
        BookContentPart3.chapter9,
        BookContentPart3.chapter10,
        BookContentPart3.chapter11,
        BookContentPart3.chapter12
    )

    private var loadedChapters: List<BookChapter> = defaultChapters

    val allChapters: List<BookChapter>
        get() = loadedChapters

    fun loadFromAssets(context: Context) {
        try {
            val jsonString = context.assets.open("book_content.json").bufferedReader().use { it.readText() }
            val root = JSONObject(jsonString)
            val chaptersArray = root.getJSONArray("chapters")
            val list = mutableListOf<BookChapter>()

            for (i in 0 until chaptersArray.length()) {
                val chObj = chaptersArray.getJSONObject(i)
                val id = chObj.getInt("id")
                val numberTitle = chObj.optString("numberTitle", "الفصل $id")
                val title = chObj.optString("title", "")
                val subtitle = chObj.optString("subtitle", "")
                val summary = chObj.optString("summary", "")

                val sectionsArray = chObj.optJSONArray("sections")
                val sectionsList = mutableListOf<ChapterSection>()

                if (sectionsArray != null) {
                    for (j in 0 until sectionsArray.length()) {
                        val secObj = sectionsArray.getJSONObject(j)
                        val secId = secObj.optString("id", "sec_${id}_$j")
                        val secTitle = secObj.optString("title", "")

                        val paragraphsList = mutableListOf<String>()
                        val pArray = secObj.optJSONArray("paragraphs")
                        if (pArray != null) {
                            for (p in 0 until pArray.length()) {
                                paragraphsList.add(pArray.getString(p))
                            }
                        }

                        val quotesList = mutableListOf<String>()
                        val qArray = secObj.optJSONArray("quranOrHadith")
                        if (qArray != null) {
                            for (q in 0 until qArray.length()) {
                                quotesList.add(qArray.getString(q))
                            }
                        }

                        val scientificNote = if (secObj.has("scientificNote")) secObj.getString("scientificNote") else null
                        val keyTakeaway = if (secObj.has("keyTakeaway")) secObj.getString("keyTakeaway") else null

                        sectionsList.add(
                            ChapterSection(
                                id = secId,
                                title = secTitle,
                                paragraphs = paragraphsList,
                                quranOrHadith = quotesList,
                                scientificNote = scientificNote,
                                keyTakeaway = keyTakeaway
                            )
                        )
                    }
                }

                list.add(
                    BookChapter(
                        id = id,
                        numberTitle = numberTitle,
                        title = title,
                        subtitle = subtitle,
                        summary = summary,
                        sections = sectionsList
                    )
                )
            }

            if (list.isNotEmpty()) {
                loadedChapters = list
            }
        } catch (e: Exception) {
            // Keep default in-memory chapters on any parse fallback
            loadedChapters = defaultChapters
        }
    }

    fun getChapter(id: Int): BookChapter? {
        return allChapters.find { it.id == id }
    }

    data class SearchResult(
        val chapter: BookChapter,
        val section: ChapterSection,
        val matchedSnippet: String
    )

    fun searchBook(query: String): List<SearchResult> {
        if (query.isBlank()) return emptyList()
        val normalizedQuery = query.trim().lowercase()
        val results = mutableListOf<SearchResult>()

        for (chapter in allChapters) {
            for (section in chapter.sections) {
                val matchedParagraph = section.paragraphs.firstOrNull {
                    it.lowercase().contains(normalizedQuery)
                } ?: section.quranOrHadith.firstOrNull {
                    it.lowercase().contains(normalizedQuery)
                } ?: if (section.title.lowercase().contains(normalizedQuery)) section.paragraphs.firstOrNull() else null

                if (matchedParagraph != null) {
                    val startIndex = matchedParagraph.lowercase().indexOf(normalizedQuery).coerceAtLeast(0)
                    val snippetStart = (startIndex - 30).coerceAtLeast(0)
                    val snippetEnd = (startIndex + normalizedQuery.length + 50).coerceAtMost(matchedParagraph.length)
                    val snippet = "..." + matchedParagraph.substring(snippetStart, snippetEnd).trim() + "..."

                    results.add(SearchResult(chapter, section, snippet))
                }
            }
        }
        return results
    }

    val dailyQuotes = listOf(
        "أنا حر.. لستُ عبداً لشهوتي، ولا لشاشة تسرق من كرامتي ورجولتي.",
        "كل رغبة لا تُكافأ بالاستجابة.. تموت وتخفت وتتلاشى.",
        "الرجولة ليست عضلات ومظهراً، بل قدرة على قول 'لا' حين يشتهي الجسد الحرام.",
        "العفة ليست حرماناً، بل باب الرزق والبركة والسكينة الحقيقية.",
        "ما سُرق منك بالمعصية يُسترد أضعافاً بالانضباط والتوكل على الله.",
        "الإرادة لا تموت، هي فقط مغطاة بركام العادة.. أزل الركام وانهض كالبطل.",
        "مرحلة الفلات لاين ليست ضعفاً، بل إعلان من جسدك أنه بدأ يتعافى في أعماقه.",
        "أنت لست ماضيك.. أنت قرارك الصادق الذي تتخذه بينك وبين ربك الآن."
    )
}
