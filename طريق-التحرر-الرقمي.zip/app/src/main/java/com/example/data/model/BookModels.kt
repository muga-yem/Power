package com.example.data.model

data class BookChapter(
    val id: Int,
    val numberTitle: String,
    val title: String,
    val subtitle: String,
    val summary: String,
    val sections: List<ChapterSection>
)

data class ChapterSection(
    val id: String,
    val title: String,
    val paragraphs: List<String>,
    val quranOrHadith: List<String> = emptyList(),
    val scientificNote: String? = null,
    val keyTakeaway: String? = null
)

enum class HabitCategory(val titleAr: String, val rangeTitle: String) {
    SPIRITUAL("العشر عادات الروحية", "العادات 1 - 10"),
    TECHNICAL("العادات التقنية", "العادات 11 - 20"),
    MENTAL("العادات العقلية لتقوية الإرادة", "العادات 21 - 30"),
    SOCIAL_LIFESTYLE("عادات اجتماعية وحياتية إيجابية", "العادات 31 - 40")
}

data class RecoveryHabit(
    val number: Int,
    val title: String,
    val category: HabitCategory,
    val description: String,
    val sacredEvidence: String? = null,
    val practicalAction: String
)

data class WithdrawalSymptom(
    val number: Int,
    val name: String,
    val briefDescription: String,
    val scientificCause: String,
    val reassurance: String,
    val stepByStepRemedy: List<String>
)

data class GreatFigure(
    val id: String,
    val name: String,
    val title: String,
    val storySummary: String,
    val mainChallenge: String,
    val turningPoint: String,
    val lessonForRecovery: String
)
