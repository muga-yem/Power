package com.example.data.local

import com.example.data.model.ChapterSection
import org.json.JSONArray
import org.json.JSONObject

object ChapterJsonConverter {
    fun sectionsToJson(sections: List<ChapterSection>): String {
        val array = JSONArray()
        for (sec in sections) {
            val obj = JSONObject()
            obj.put("id", sec.id)
            obj.put("title", sec.title)

            val pArray = JSONArray()
            sec.paragraphs.forEach { pArray.put(it) }
            obj.put("paragraphs", pArray)

            val qArray = JSONArray()
            sec.quranOrHadith.forEach { qArray.put(it) }
            obj.put("quranOrHadith", qArray)

            if (sec.scientificNote != null) obj.put("scientificNote", sec.scientificNote)
            if (sec.keyTakeaway != null) obj.put("keyTakeaway", sec.keyTakeaway)

            array.put(obj)
        }
        return array.toString()
    }

    fun jsonToSections(jsonString: String): List<ChapterSection> {
        val list = mutableListOf<ChapterSection>()
        try {
            val array = JSONArray(jsonString)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.optString("id", "sec_$i")
                val title = obj.optString("title", "")

                val paragraphs = mutableListOf<String>()
                val pArray = obj.optJSONArray("paragraphs")
                if (pArray != null) {
                    for (p in 0 until pArray.length()) {
                        paragraphs.add(pArray.getString(p))
                    }
                }

                val quranOrHadith = mutableListOf<String>()
                val qArray = obj.optJSONArray("quranOrHadith")
                if (qArray != null) {
                    for (q in 0 until qArray.length()) {
                        quranOrHadith.add(qArray.getString(q))
                    }
                }

                val scientificNote = if (obj.has("scientificNote")) obj.getString("scientificNote") else null
                val keyTakeaway = if (obj.has("keyTakeaway")) obj.getString("keyTakeaway") else null

                list.add(
                    ChapterSection(
                        id = id,
                        title = title,
                        paragraphs = paragraphs,
                        quranOrHadith = quranOrHadith,
                        scientificNote = scientificNote,
                        keyTakeaway = keyTakeaway
                    )
                )
            }
        } catch (_: Exception) {
            // fallback empty
        }
        return list
    }
}
