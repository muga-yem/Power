package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recovery_profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val streakStartEpochMs: Long = System.currentTimeMillis(),
    val longestStreakDays: Int = 0,
    val totalRelapses: Int = 0,
    val userStatus: String = "SINGLE", // ADOLESCENT, SINGLE, MARRIED
    val userName: String = "البطل المحارب",
    val pinCode: String = "",
    val isPinEnabled: Boolean = false,
    val isDarkMode: Boolean = true,
    val fontScale: Float = 1.0f,
    val covenantSigned: Boolean = false,
    val covenantSignatureName: String = "",
    val covenantSignatureDate: String = "",
    val adminPinCode: String = "9999",
    // Smart Reminders settings
    val remindersEnabled: Boolean = true,
    val morningReminderEnabled: Boolean = true,
    val eveningReminderEnabled: Boolean = true,
    val lateNightGuardEnabled: Boolean = true,
    val motivationalQuotesIntervalHours: Int = 4,
    // Detox stats
    val totalDetoxMinutes: Int = 0,
    val completedDetoxSessions: Int = 0
)

@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val isVictory: Boolean = true, // true = انتصار وصمود, false = تعثر / انتكاسة
    val title: String,
    val triggerFactor: String,
    val feelings: String,
    val actionOrLesson: String
)

@Entity(tableName = "daily_records")
data class DailyRecordEntity(
    @PrimaryKey val dateKey: String, // e.g. "2026-10-11"
    val morningAthkarDone: Boolean = false,
    val eveningAthkarDone: Boolean = false,
    val quranDone: Boolean = false,
    val prayersOnTime: Boolean = false,
    val coldShowerDone: Boolean = false,
    val workoutDone: Boolean = false,
    val screenLimitDone: Boolean = false,
    val gratitude1: String = "",
    val gratitude2: String = "",
    val gratitude3: String = "",
    val eveningRating: Int = 5, // 1 to 5
    val eveningReflection: String = "",
    val subconsciousAffirmationRead: Boolean = false
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chapterId: Int,
    val chapterTitle: String,
    val sectionTitle: String,
    val excerptText: String,
    val personalNote: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_chapters")
data class ChapterEntity(
    @PrimaryKey val id: Int,
    val numberTitle: String,
    val title: String,
    val subtitle: String,
    val summary: String,
    val sectionsJson: String // serialized JSON array of ChapterSection
)

@Entity(tableName = "custom_daily_plans")
data class CustomDailyPlanEntity(
    @PrimaryKey val dayNumber: Int, // 1 to 40
    val title: String,
    val habitFocus: String,
    val spiritualTask: String,
    val practicalTask: String,
    val quranVerseOrHadith: String,
    val dailyAffirmation: String,
    val motivationalQuote: String
)
