package com.example.data.repository

import android.content.Context
import com.example.data.local.BookmarkEntity
import com.example.data.local.ChapterEntity
import com.example.data.local.ChapterJsonConverter
import com.example.data.local.CustomDailyPlanEntity
import com.example.data.local.DailyRecordEntity
import com.example.data.local.JournalEntryEntity
import com.example.data.local.ProfileEntity
import com.example.data.local.RecoveryDao
import com.example.data.model.BookChapter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecoveryRepository(private val dao: RecoveryDao) {

    suspend fun seedInitialDataIfEmpty(context: Context) {
        // Ensure default profile
        ensureProfile()

        // 1. Seed Chapters if empty
        if (dao.getChaptersCount() == 0) {
            BookRepository.loadFromAssets(context)
            val defaults = BookRepository.allChapters
            val entities = defaults.map { ch ->
                ChapterEntity(
                    id = ch.id,
                    numberTitle = ch.numberTitle,
                    title = ch.title,
                    subtitle = ch.subtitle,
                    summary = ch.summary,
                    sectionsJson = ChapterJsonConverter.sectionsToJson(ch.sections)
                )
            }
            dao.insertChaptersList(entities)
        }

        // 2. Seed Daily 40-Day Plans if empty
        if (dao.getCustomDailyPlansCount() == 0) {
            val defaults = FortyDaysPlanDataSource.days
            val entities = defaults.map { p ->
                CustomDailyPlanEntity(
                    dayNumber = p.dayNumber,
                    title = p.title,
                    habitFocus = p.habitFocus,
                    spiritualTask = p.spiritualTask,
                    practicalTask = p.practicalTask,
                    quranVerseOrHadith = p.quranVerseOrHadith,
                    dailyAffirmation = p.dailyAffirmation,
                    motivationalQuote = p.motivationalQuote
                )
            }
            dao.insertDailyPlansList(entities)
        }
    }

    // Chapters Flow
    fun getAllChaptersFlow(): Flow<List<BookChapter>> {
        return dao.getAllChaptersFlow().map { entities ->
            if (entities.isEmpty()) {
                BookRepository.allChapters
            } else {
                entities.map { entity ->
                    BookChapter(
                        id = entity.id,
                        numberTitle = entity.numberTitle,
                        title = entity.title,
                        subtitle = entity.subtitle,
                        summary = entity.summary,
                        sections = ChapterJsonConverter.jsonToSections(entity.sectionsJson)
                    )
                }
            }
        }
    }

    suspend fun saveChapter(chapter: BookChapter) {
        dao.upsertChapter(
            ChapterEntity(
                id = chapter.id,
                numberTitle = chapter.numberTitle,
                title = chapter.title,
                subtitle = chapter.subtitle,
                summary = chapter.summary,
                sectionsJson = ChapterJsonConverter.sectionsToJson(chapter.sections)
            )
        )
    }

    suspend fun deleteChapter(chapterId: Int) {
        dao.deleteChapterById(chapterId)
    }

    suspend fun resetChaptersToDefault(context: Context) {
        dao.clearAllChapters()
        BookRepository.loadFromAssets(context)
        val defaults = BookRepository.allChapters
        val entities = defaults.map { ch ->
            ChapterEntity(
                id = ch.id,
                numberTitle = ch.numberTitle,
                title = ch.title,
                subtitle = ch.subtitle,
                summary = ch.summary,
                sectionsJson = ChapterJsonConverter.sectionsToJson(ch.sections)
            )
        }
        dao.insertChaptersList(entities)
    }

    // 40-Day Plans Flow
    fun getAllDailyPlansFlow(): Flow<List<DailyJourneyPlan>> {
        return dao.getAllCustomDailyPlansFlow().map { entities ->
            if (entities.isEmpty()) {
                FortyDaysPlanDataSource.days
            } else {
                entities.map { entity ->
                    DailyJourneyPlan(
                        dayNumber = entity.dayNumber,
                        title = entity.title,
                        habitFocus = entity.habitFocus,
                        spiritualTask = entity.spiritualTask,
                        practicalTask = entity.practicalTask,
                        quranVerseOrHadith = entity.quranVerseOrHadith,
                        dailyAffirmation = entity.dailyAffirmation,
                        motivationalQuote = entity.motivationalQuote
                    )
                }
            }
        }
    }

    suspend fun saveDailyPlan(plan: DailyJourneyPlan) {
        dao.upsertCustomDailyPlan(
            CustomDailyPlanEntity(
                dayNumber = plan.dayNumber,
                title = plan.title,
                habitFocus = plan.habitFocus,
                spiritualTask = plan.spiritualTask,
                practicalTask = plan.practicalTask,
                quranVerseOrHadith = plan.quranVerseOrHadith,
                dailyAffirmation = plan.dailyAffirmation,
                motivationalQuote = plan.motivationalQuote
            )
        )
    }

    suspend fun resetDailyPlansToDefault() {
        dao.clearAllDailyPlans()
        val defaults = FortyDaysPlanDataSource.days
        val entities = defaults.map { p ->
            CustomDailyPlanEntity(
                dayNumber = p.dayNumber,
                title = p.title,
                habitFocus = p.habitFocus,
                spiritualTask = p.spiritualTask,
                practicalTask = p.practicalTask,
                quranVerseOrHadith = p.quranVerseOrHadith,
                dailyAffirmation = p.dailyAffirmation,
                motivationalQuote = p.motivationalQuote
            )
        }
        dao.insertDailyPlansList(entities)
    }

    // Profile & Streak
    fun getProfileFlow(): Flow<ProfileEntity> {
        return dao.getProfileFlow().map { profile ->
            profile ?: ProfileEntity()
        }
    }

    suspend fun ensureProfile(): ProfileEntity {
        val existing = dao.getProfileSync()
        if (existing == null) {
            val def = ProfileEntity()
            dao.upsertProfile(def)
            return def
        }
        return existing
    }

    suspend fun verifyAdminPin(pin: String): Boolean {
        val profile = ensureProfile()
        return pin == profile.adminPinCode
    }

    suspend fun updateAdminPin(newPin: String) {
        val profile = ensureProfile()
        dao.upsertProfile(profile.copy(adminPinCode = newPin))
    }

    suspend fun updateUserStatus(status: String) {
        val current = ensureProfile()
        dao.upsertProfile(current.copy(userStatus = status))
    }

    suspend fun updateUserName(name: String) {
        val current = ensureProfile()
        dao.upsertProfile(current.copy(userName = name))
    }

    suspend fun updateFontScale(scale: Float) {
        val current = ensureProfile()
        dao.upsertProfile(current.copy(fontScale = scale))
    }

    suspend fun updateTheme(isDark: Boolean) {
        val current = ensureProfile()
        dao.upsertProfile(current.copy(isDarkMode = isDark))
    }

    suspend fun updatePin(pin: String, enabled: Boolean) {
        val current = ensureProfile()
        dao.upsertProfile(current.copy(pinCode = pin, isPinEnabled = enabled))
    }

    suspend fun signCovenant(signatureName: String) {
        val current = ensureProfile()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        dao.upsertProfile(
            current.copy(
                covenantSigned = true,
                covenantSignatureName = signatureName,
                covenantSignatureDate = dateFormat.format(Date())
            )
        )
    }

    suspend fun resetStreak(trigger: String, feelings: String, lesson: String) {
        val current = ensureProfile()
        val now = System.currentTimeMillis()
        val streakDays = ((now - current.streakStartEpochMs) / (1000 * 60 * 60 * 24)).toInt()
        val newLongest = maxOf(current.longestStreakDays, streakDays)

        dao.insertJournalEntry(
            JournalEntryEntity(
                timestamp = now,
                isVictory = false,
                title = "تعثر في مسار التعافي (يوم $streakDays)",
                triggerFactor = trigger.ifBlank { "غير محدد" },
                feelings = feelings.ifBlank { "ندم ورغبة صادقة في العودة الفورية" },
                actionOrLesson = lesson.ifBlank { "الاستغفار، الوضوء، والنهوض دون يأس" }
            )
        )

        dao.upsertProfile(
            current.copy(
                streakStartEpochMs = now,
                longestStreakDays = newLongest,
                totalRelapses = current.totalRelapses + 1
            )
        )
    }

    suspend fun recordVictory(title: String, trigger: String, feelings: String, action: String) {
        dao.insertJournalEntry(
            JournalEntryEntity(
                timestamp = System.currentTimeMillis(),
                isVictory = true,
                title = title.ifBlank { "انتصار وصمود أمام الرغبة" },
                triggerFactor = trigger,
                feelings = feelings,
                actionOrLesson = action
            )
        )
    }

    fun getAllJournalEntries(): Flow<List<JournalEntryEntity>> = dao.getAllJournalEntriesFlow()

    suspend fun deleteJournalEntry(entry: JournalEntryEntity) = dao.deleteJournalEntry(entry)

    fun getDailyRecordFlow(dateKey: String): Flow<DailyRecordEntity?> = dao.getDailyRecordFlow(dateKey)

    suspend fun getDailyRecordSync(dateKey: String): DailyRecordEntity {
        return dao.getDailyRecordSync(dateKey) ?: DailyRecordEntity(dateKey = dateKey)
    }

    suspend fun upsertDailyRecord(record: DailyRecordEntity) {
        dao.upsertDailyRecord(record)
    }

    fun getAllBookmarks(): Flow<List<BookmarkEntity>> = dao.getAllBookmarksFlow()

    suspend fun addBookmark(chapterId: Int, chapterTitle: String, sectionTitle: String, excerpt: String, note: String) {
        dao.insertBookmark(
            BookmarkEntity(
                chapterId = chapterId,
                chapterTitle = chapterTitle,
                sectionTitle = sectionTitle,
                excerptText = excerpt,
                personalNote = note
            )
        )
    }

    suspend fun deleteBookmark(bookmark: BookmarkEntity) = dao.deleteBookmark(bookmark)

    // Reminders settings
    suspend fun updateReminderSettings(
        enabled: Boolean,
        morning: Boolean,
        evening: Boolean,
        lateNight: Boolean
    ) {
        val current = ensureProfile()
        dao.upsertProfile(
            current.copy(
                remindersEnabled = enabled,
                morningReminderEnabled = morning,
                eveningReminderEnabled = evening,
                lateNightGuardEnabled = lateNight
            )
        )
    }

    // Detox stats
    suspend fun recordCompletedDetox(minutes: Int) {
        val current = ensureProfile()
        dao.upsertProfile(
            current.copy(
                totalDetoxMinutes = current.totalDetoxMinutes + minutes,
                completedDetoxSessions = current.completedDetoxSessions + 1
            )
        )
    }
}

