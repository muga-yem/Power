package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RecoveryDao {
    // Profile & Streak
    @Query("SELECT * FROM recovery_profile WHERE id = 1 LIMIT 1")
    fun getProfileFlow(): Flow<ProfileEntity?>

    @Query("SELECT * FROM recovery_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileSync(): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: ProfileEntity)

    // Journal
    @Query("SELECT * FROM journal_entries ORDER BY timestamp DESC")
    fun getAllJournalEntriesFlow(): Flow<List<JournalEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournalEntry(entry: JournalEntryEntity): Long

    @Delete
    suspend fun deleteJournalEntry(entry: JournalEntryEntity)

    // Daily 40-day Records
    @Query("SELECT * FROM daily_records WHERE dateKey = :dateKey LIMIT 1")
    fun getDailyRecordFlow(dateKey: String): Flow<DailyRecordEntity?>

    @Query("SELECT * FROM daily_records WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getDailyRecordSync(dateKey: String): DailyRecordEntity?

    @Query("SELECT * FROM daily_records ORDER BY dateKey DESC")
    fun getAllDailyRecordsFlow(): Flow<List<DailyRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyRecord(record: DailyRecordEntity)

    // Bookmarks
    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarksFlow(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity): Long

    @Delete
    suspend fun deleteBookmark(bookmark: BookmarkEntity)

    // Custom Chapters (Admin Management)
    @Query("SELECT * FROM custom_chapters ORDER BY id ASC")
    fun getAllChaptersFlow(): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM custom_chapters WHERE id = :id LIMIT 1")
    suspend fun getChapterById(id: Int): ChapterEntity?

    @Query("SELECT COUNT(*) FROM custom_chapters")
    suspend fun getChaptersCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChapter(chapter: ChapterEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChaptersList(chapters: List<ChapterEntity>)

    @Delete
    suspend fun deleteChapter(chapter: ChapterEntity)

    @Query("DELETE FROM custom_chapters WHERE id = :id")
    suspend fun deleteChapterById(id: Int)

    @Query("DELETE FROM custom_chapters")
    suspend fun clearAllChapters()

    // Custom 40-day Plans (Admin Management)
    @Query("SELECT * FROM custom_daily_plans ORDER BY dayNumber ASC")
    fun getAllCustomDailyPlansFlow(): Flow<List<CustomDailyPlanEntity>>

    @Query("SELECT COUNT(*) FROM custom_daily_plans")
    suspend fun getCustomDailyPlansCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomDailyPlan(plan: CustomDailyPlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyPlansList(plans: List<CustomDailyPlanEntity>)

    @Query("DELETE FROM custom_daily_plans")
    suspend fun clearAllDailyPlans()
}
