package com.example.data.model

enum class UserStatus(val titleAr: String, val descriptionAr: String) {
    ADOLESCENT("مراهق", "توجيهات لسن البناء، حماية القشرة الجبهية، والتحصيل الدراسي"),
    SINGLE("أعزب", "توجيهات لحفظ البصر، تصريف الطاقة في الإنجاز والرياضة والعفة"),
    MARRIED("متزوج", "توجيهات لإصلاح المودة والسكينة الزوجية وكسر المقارنات الوهمية")
}

data class RecoveryBadge(
    val id: String,
    val title: String,
    val requiredDays: Int,
    val description: String,
    val iconEmoji: String
)

object BadgesData {
    val allBadges = listOf(
        RecoveryBadge("badge_3", "بداية البصيرة", 3, "تجاوزت أول 72 ساعة الصعبة وكسرت الصدمة الأولى", "🌱"),
        RecoveryBadge("badge_7", "أسبوع النقاء", 7, "أتممت 7 أيام وبدأ الدوبامين يستعيد توازنه الطبيعي", "🛡️"),
        RecoveryBadge("badge_14", "حصن الإرادة", 14, "أسبوعان من الصمود وبداية زوال الضباب الذهني", "⚡"),
        RecoveryBadge("badge_30", "نجم الثبات", 30, "شهر كامل من الحرية وتجدد خلايا الدماغ", "🌟"),
        RecoveryBadge("badge_40", "بطل الأربعين يوماً", 40, "أتممت برنامج الـ 40 يوماً واكتسبت عادات العظماء", "🏆"),
        RecoveryBadge("badge_60", "طاقة الرجولة", 60, "شهران من التحرر، هرمونات متزنة وهيبة مستعادة", "🦅"),
        RecoveryBadge("badge_90", "التحرر الكامل", 90, "إعادة تشكيل المسارات العصبية وولادة الإنسان الجديد", "👑")
    )
}
