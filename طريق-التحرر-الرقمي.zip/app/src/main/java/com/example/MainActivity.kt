package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.PinLockScreen
import com.example.ui.components.RelapseResetDialog
import com.example.ui.components.SosEmergencyDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.BookReaderScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DigitalDetoxScreen
import com.example.ui.screens.FortyDaysJourneyScreen
import com.example.ui.screens.GreatFiguresScreen
import com.example.ui.screens.JournalScreen
import com.example.ui.screens.NewVictoryEntryDialog
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WithdrawalGuideScreen
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.TariqAlTaharrurTheme
import com.example.ui.viewmodel.RecoveryViewModel

enum class AppScreen {
    DASHBOARD,
    BOOK,
    FORTY_DAYS,
    WITHDRAWAL,
    JOURNAL,
    GREAT_FIGURES,
    DETOX,
    SETTINGS,
    ADMIN
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: RecoveryViewModel = viewModel()
            val profile by viewModel.profileState.collectAsState()
            val isUnlocked by viewModel.isAppUnlocked.collectAsState()

            // Request Notification Permission for Android 13+ (API 33+)
            val notificationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
            ) { isGranted ->
                if (isGranted && profile.remindersEnabled) {
                    viewModel.updateReminderSettings(
                        profile.remindersEnabled,
                        profile.morningReminderEnabled,
                        profile.eveningReminderEnabled,
                        profile.lateNightGuardEnabled
                    )
                }
            }

            androidx.compose.runtime.LaunchedEffect(Unit) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        android.Manifest.permission.POST_NOTIFICATIONS
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!hasPermission) {
                        notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            TariqAlTaharrurTheme(darkTheme = profile.isDarkMode) {
                // Ensure RTL layout for Arabic
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    if (profile.isPinEnabled && !isUnlocked && profile.pinCode.isNotBlank()) {
                        PinLockScreen(
                            correctPin = profile.pinCode,
                            onSuccessUnlock = { viewModel.unlockApp() }
                        )
                    } else {
                        MainAppContent(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: RecoveryViewModel) {
    val profile by viewModel.profileState.collectAsState()
    val chapters by viewModel.chaptersState.collectAsState()
    val dailyPlans by viewModel.dailyPlansState.collectAsState()
    val journalEntries by viewModel.journalEntriesState.collectAsState()
    val bookmarks by viewModel.bookmarksState.collectAsState()
    val todayRecord by viewModel.todayRecordState.collectAsState()

    var currentScreen by remember { mutableStateOf(AppScreen.DASHBOARD) }
    var bookSelectedChapterId by remember { mutableIntStateOf(0) }
    var showSosDialog by remember { mutableStateOf(false) }
    var showRelapseDialog by remember { mutableStateOf(false) }
    var showVictoryDialog by remember { mutableStateOf(false) }

    // Handle back button for sub screens
    if (currentScreen != AppScreen.DASHBOARD) {
        BackHandler {
            if (currentScreen == AppScreen.ADMIN) {
                currentScreen = AppScreen.SETTINGS
            } else {
                currentScreen = AppScreen.DASHBOARD
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (currentScreen != AppScreen.ADMIN && currentScreen != AppScreen.DETOX) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.DASHBOARD,
                        onClick = { currentScreen = AppScreen.DASHBOARD },
                        icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                        label = { Text("الرئيسية", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimaryDark,
                            selectedTextColor = EmeraldPrimaryDark,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.BOOK,
                        onClick = { currentScreen = AppScreen.BOOK },
                        icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "الكتاب") },
                        label = { Text("الكتاب", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimaryDark,
                            selectedTextColor = EmeraldPrimaryDark,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.FORTY_DAYS,
                        onClick = { currentScreen = AppScreen.FORTY_DAYS },
                        icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "الـ 40 يوماً") },
                        label = { Text("الـ 40 يوماً", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimaryDark,
                            selectedTextColor = EmeraldPrimaryDark,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.WITHDRAWAL,
                        onClick = { currentScreen = AppScreen.WITHDRAWAL },
                        icon = { Icon(Icons.Default.MedicalServices, contentDescription = "الأعراض") },
                        label = { Text("الأعراض", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimaryDark,
                            selectedTextColor = EmeraldPrimaryDark,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.JOURNAL,
                        onClick = { currentScreen = AppScreen.JOURNAL },
                        icon = { Icon(Icons.Default.EditNote, contentDescription = "السجل") },
                        label = { Text("السجل", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimaryDark,
                            selectedTextColor = EmeraldPrimaryDark,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        androidx.compose.foundation.layout.Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
                AppScreen.DASHBOARD -> DashboardScreen(
                    profile = profile,
                    onOpenSos = { showSosDialog = true },
                    onNavigateToBook = { chapterId ->
                        bookSelectedChapterId = chapterId
                        currentScreen = AppScreen.BOOK
                    },
                    onNavigateToFortyDays = { currentScreen = AppScreen.FORTY_DAYS },
                    onNavigateToWithdrawal = { currentScreen = AppScreen.WITHDRAWAL },
                    onNavigateToJournal = { currentScreen = AppScreen.JOURNAL },
                    onNavigateToGreatFigures = { currentScreen = AppScreen.GREAT_FIGURES },
                    onNavigateToDetox = { currentScreen = AppScreen.DETOX },
                    onNavigateToSettings = { currentScreen = AppScreen.SETTINGS },
                    onLogVictory = { showVictoryDialog = true },
                    onResetStreak = { showRelapseDialog = true }
                )

                AppScreen.BOOK -> BookReaderScreen(
                    initialChapterId = bookSelectedChapterId,
                    chapters = chapters,
                    bookmarks = bookmarks,
                    onAddBookmark = { chId, chTitle, secTitle, excerpt, note ->
                        viewModel.addBookmark(chId, chTitle, secTitle, excerpt, note)
                    },
                    onDeleteBookmark = { bm -> viewModel.deleteBookmark(bm) },
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.FORTY_DAYS -> FortyDaysJourneyScreen(
                    currentDailyRecord = todayRecord,
                    dailyPlans = dailyPlans,
                    onSaveDailyRecord = { record -> viewModel.saveDailyRecord(record) },
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.WITHDRAWAL -> WithdrawalGuideScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.JOURNAL -> JournalScreen(
                    entries = journalEntries,
                    onAddVictory = { title, trigger, feelings, action ->
                        viewModel.logVictory(title, trigger, feelings, action)
                    },
                    onDeleteEntry = { entry -> viewModel.deleteJournalEntry(entry) },
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.GREAT_FIGURES -> GreatFiguresScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.DETOX -> DigitalDetoxScreen(
                    profile = profile,
                    onRecordDetoxCompleted = { minutes ->
                        viewModel.recordCompletedDetox(minutes)
                    },
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.SETTINGS -> SettingsScreen(
                    profile = profile,
                    onUpdateStatus = { status -> viewModel.updateUserStatus(status) },
                    onUpdateName = { name -> viewModel.updateUserName(name) },
                    onUpdatePin = { pin, enabled -> viewModel.updatePin(pin, enabled) },
                    onUpdateReminders = { enabled, morning, evening, lateNight ->
                        viewModel.updateReminderSettings(enabled, morning, evening, lateNight)
                    },
                    onTestNotification = {
                        viewModel.sendTestMotivationalNotification()
                    },
                    onSignCovenant = { signName -> viewModel.signCovenant(signName) },
                    onNavigateToAdmin = { currentScreen = AppScreen.ADMIN },
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.ADMIN -> AdminDashboardScreen(
                    profile = profile,
                    chapters = chapters,
                    dailyPlans = dailyPlans,
                    onSaveChapter = { ch -> viewModel.saveChapter(ch) },
                    onDeleteChapter = { id -> viewModel.deleteChapter(id) },
                    onResetChapters = { viewModel.resetChaptersToDefault() },
                    onSaveDailyPlan = { plan -> viewModel.saveDailyPlan(plan) },
                    onResetDailyPlans = { viewModel.resetDailyPlansToDefault() },
                    onUpdateAdminPin = { pin -> viewModel.updateAdminPin(pin) },
                    onBack = { currentScreen = AppScreen.SETTINGS }
                )
            }
        }
    }

    // SOS Urge Intervention Dialog
    if (showSosDialog) {
        SosEmergencyDialog(
            onDismiss = { showSosDialog = false },
            onUrgeOvercome = {
                viewModel.logVictory(
                    title = "انتصار بطولي عبر زر الطوارئ (SOS)",
                    trigger = "رغبة حادة مفاجئة",
                    feelings = "تجاوزت الضعف بتمرين التنفس واستحضار أسئلة قطع الوهم",
                    action = "استعاذة، وضوء، وكسر حلقة الرغبة"
                )
            }
        )
    }

    // Relapse Reset Dialog
    if (showRelapseDialog) {
        RelapseResetDialog(
            onDismiss = { showRelapseDialog = false },
            onConfirmReset = { trigger, feelings, lesson ->
                viewModel.resetStreak(trigger, feelings, lesson)
            }
        )
    }

    // Log Victory Dialog
    if (showVictoryDialog) {
        NewVictoryEntryDialog(
            onDismiss = { showVictoryDialog = false },
            onSave = { title, trigger, feelings, action ->
                viewModel.logVictory(title, trigger, feelings, action)
                showVictoryDialog = false
            }
        )
    }
}
