package com.example.ui.screens

import android.app.Activity
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ProfileEntity
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldContainerDark
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.RedEmergency
import com.example.ui.theme.SkyTertiaryDark
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalDetoxScreen(
    profile: ProfileEntity,
    onRecordDetoxCompleted: (minutes: Int) -> Unit,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: وضع الانفصال, 1: وضع التنفس والتأمل

    // State for Detox Challenge Timer
    var isDetoxActive by remember { mutableStateOf(false) }
    var selectedDurationMinutes by remember { mutableIntStateOf(30) } // 15, 30, 60, 120, 180, 480
    var remainingSeconds by remember { mutableIntStateOf(30 * 60) }
    var showCancelWarningDialog by remember { mutableStateOf(false) }
    var showCompletedDialog by remember { mutableStateOf(false) }

    // Keep screen on when in detox or breathing mode
    val context = LocalContext.current
    DisposableEffect(isDetoxActive) {
        val window = (context as? Activity)?.window
        if (isDetoxActive) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Countdown effect
    LaunchedEffect(isDetoxActive, remainingSeconds) {
        if (isDetoxActive && remainingSeconds > 0) {
            delay(1000L)
            remainingSeconds -= 1
            if (remainingSeconds == 0) {
                isDetoxActive = false
                onRecordDetoxCompleted(selectedDurationMinutes)
                showCompletedDialog = true
            }
        }
    }

    // BackHandler when detox is active warns user
    BackHandler {
        if (isDetoxActive) {
            showCancelWarningDialog = true
        } else {
            onBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = AmberSecondaryDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "وضع حارس الليل والانفصال",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isDetoxActive) showCancelWarningDialog = true else onBack()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("digital_detox_screen")
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = EmeraldPrimaryDark
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { if (!isDetoxActive) selectedTab = 0 },
                    text = {
                        Text(
                            text = "تحدي الانفصال عن الجوال",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    },
                    icon = { Icon(Icons.Default.HourglassBottom, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { if (!isDetoxActive) selectedTab = 1 },
                    text = {
                        Text(
                            text = "وضع التأمل والتنفس العميق",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    },
                    icon = { Icon(Icons.Default.SelfImprovement, contentDescription = null) }
                )
            }

            if (selectedTab == 0) {
                DetoxChallengeTab(
                    isActive = isDetoxActive,
                    selectedMinutes = selectedDurationMinutes,
                    remainingSeconds = remainingSeconds,
                    totalDetoxMinutes = profile.totalDetoxMinutes,
                    completedSessions = profile.completedDetoxSessions,
                    onSelectDuration = { mins ->
                        selectedDurationMinutes = mins
                        remainingSeconds = mins * 60
                    },
                    onStart = {
                        remainingSeconds = selectedDurationMinutes * 60
                        isDetoxActive = true
                    },
                    onStopRequest = { showCancelWarningDialog = true }
                )
            } else {
                BreathingMeditationTab()
            }
        }
    }

    // Cancel warning dialog
    if (showCancelWarningDialog) {
        AlertDialog(
            onDismissRequest = { showCancelWarningDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = RedEmergency,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "هل تريد الاستسلام وإلغاء التحدي؟",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "المحارب لا ينقض عهده مع نفسه. تذكر القاعدة الذهبية في الكتاب: 'المعركة تحسم في لحظات الصبر الأولى'. اصبر وابقَ بعيداً عن الشاشة حتى ينتهي الوقت!",
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showCancelWarningDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark)
                ) {
                    Text("مستمر في التحدي والصمود", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCancelWarningDialog = false
                        isDetoxActive = false
                    }
                ) {
                    Text("إنهاء التحدي الآن", color = RedEmergency)
                }
            }
        )
    }

    // Completed dialog
    if (showCompletedDialog) {
        AlertDialog(
            onDismissRequest = { showCompletedDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = EmeraldPrimaryDark,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "مبروك أيها البطل! انتصار عظيم",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "لقد أتممت تحدي الانفصال عن الجوال لمدة $selectedDurationMinutes دقيقة بنجاح كامل! أثبت لنفسك أنك لست عبداً لهذا الجهاز وأنك تملك زمام إرادتك.",
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showCompletedDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark)
                ) {
                    Text("الحمد لله.. سأواصل", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun DetoxChallengeTab(
    isActive: Boolean,
    selectedMinutes: Int,
    remainingSeconds: Int,
    totalDetoxMinutes: Int,
    completedSessions: Int,
    onSelectDuration: (Int) -> Unit,
    onStart: () -> Unit,
    onStopRequest: () -> Unit
) {
    val durationOptions = listOf(
        Pair(15, "15 دقيقة (كسر الرغبة)"),
        Pair(30, "30 دقيقة (جلسة تركيز)"),
        Pair(60, "ساعة كاملة (قراءة/عبادة)"),
        Pair(120, "ساعتان (حظر المساء)"),
        Pair(240, "4 ساعات (حارس الليل)"),
        Pair(480, "8 ساعات (نوم نقي بلا شاشات)")
    )

    val currentQuote = remember(remainingSeconds / 60) {
        val quotes = listOf(
            "«أنا حر، لست عبداً لشهوتي ولست أسيراً لشاشتي»",
            "كل دقيقة تبعد فيها عن الجوال يعود فيها صفاء ذهنك وقوة انتباهك.",
            "الوقت المتأخر في الليل مصيدة؛ ضع الجوال في غرفة أخرى وتذكر وعدك لله.",
            "الدوبامين الحقيقي يُبنى بالإنجاز والعبادة والصبر، لا بومضات التمرير اللانهائي.",
            "«لَنْ تَهْزِمَنِي بَعْدَ الْيَوْم!» — قوتك اليوم قرار يتجدد."
        )
        quotes[(remainingSeconds / 60) % quotes.size]
    }

    if (isActive) {
        // Active challenge full screen view
        val hours = remainingSeconds / 3600
        val mins = (remainingSeconds % 3600) / 60
        val secs = remainingSeconds % 60
        val timeDisplay = if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, mins, secs)
        } else {
            String.format("%02d:%02d", mins, secs)
        }

        val totalSecs = selectedMinutes * 60
        val progress = if (totalSecs > 0) (totalSecs - remainingSeconds).toFloat() / totalSecs else 0f

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0B1120), Color(0xFF0F172A), Color(0xFF022C22))
                    )
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(EmeraldContainerDark)
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "🛡️ وضع حارس الليل نشط ومغلق",
                        color = EmeraldPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "تحدي الانفصال عن الجوال",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Text(
                    text = "ضع الهاتف جانباً واشغل نفسك بذكر أو قراءة أو نوم",
                    fontSize = 13.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center
                )
            }

            // Big Timer Indicator
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    color = AmberSecondaryDark,
                    trackColor = Color(0xFF1E293B),
                    strokeWidth = 10.dp
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = AmberSecondaryDark,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = timeDisplay,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "الوقت المتبقي للصمود",
                        fontSize = 12.sp,
                        color = AmberSecondaryDark
                    )
                }
            }

            // Motivational quote card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EmeraldPrimaryDark.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = currentQuote,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )
                }
            }

            // Cancel / Emergency release button
            OutlinedButton(
                onClick = onStopRequest,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("إلغاء التحدي (لحالات الضرورة)")
            }
        }
    } else {
        // Setup Screen
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stats Header
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$completedSessions",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldPrimaryDark
                            )
                            Text(
                                text = "جلسات ناجحة",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(36.dp)
                                .width(1.dp)
                                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${totalDetoxMinutes / 60}h ${totalDetoxMinutes % 60}m",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AmberSecondaryDark
                            )
                            Text(
                                text = "إجمالي الانفصال",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Introduction & Advice
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AmberSecondaryDark.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Nightlight,
                                contentDescription = null,
                                tint = AmberSecondaryDark,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "لماذا وضع حارس الليل والانفصال؟",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = AmberSecondaryDark
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "أثبتت دراسات كتاب 'طريق التحرر' أن أكثر من 85% من الانتكاسات تحدث في أوقات الفراغ المتأخرة والوحدة مع الجوال. عندما تشعر برغبة أو ضعف، قفل شاشتك والانفصال عن الهاتف هو درعك الحصين الأول.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Select Duration
            item {
                Text(
                    text = "اختر مدة التحدي والانفصال:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    durationOptions.forEach { (mins, label) ->
                        val isSelected = selectedMinutes == mins
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) EmeraldPrimaryDark else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) EmeraldPrimaryDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectDuration(mins) }
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = label,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Start Button
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onStart,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_detox_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "بدء تحدي الانفصال ($selectedMinutes دقيقة)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun BreathingMeditationTab() {
    // 4-7-8 Breathing technique or Box breathing (شهيق 4s - حبس 4s - زفير 6s)
    var isBreathingActive by remember { mutableStateOf(false) }
    var phase by remember { mutableStateOf("استعد") } // استعد, شهيق, حبس النفس, زفير
    var secondsInPhase by remember { mutableIntStateOf(4) }
    var cycleCount by remember { mutableIntStateOf(0) }

    // Pulsing circle animation
    val infiniteTransition = rememberInfiniteTransition(label = "breathing")
    val scaleAnim by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    LaunchedEffect(isBreathingActive) {
        if (isBreathingActive) {
            while (true) {
                // الشهيق: 4 ثوان
                phase = "شَهِيق عَمِيق (املأ الرئتين)"
                for (s in 4 downTo 1) {
                    secondsInPhase = s
                    delay(1000L)
                }

                // الحبس: 4 ثوان
                phase = "احْبِس النَّفَس (اهدأ وركّز)"
                for (s in 4 downTo 1) {
                    secondsInPhase = s
                    delay(1000L)
                }

                // الزفير: 6 ثوان
                phase = "زَفِير بَطِيء (أخرج كل التوتر)"
                for (s in 6 downTo 1) {
                    secondsInPhase = s
                    delay(1000L)
                }

                cycleCount += 1
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF064E3B))
                )
            )
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(EmeraldContainerDark)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "تقنية التنفس العميق لطرد إلحاح الدوبامين",
                    color = EmeraldPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "جلسة تصفية العقل والاسترخاء",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "التنفس العميق يعيد تنشيط الجهاز العصبي الباراسمبثاوي ويهدئ رغبة الدماغ الملحة",
                fontSize = 12.sp,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )
        }

        // Animated Breathing Visualizer
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(260.dp)
        ) {
            // Outer glow circle
            Box(
                modifier = Modifier
                    .size(250.dp)
                    .scale(if (isBreathingActive) scaleAnim else 0.8f)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(EmeraldPrimaryDark.copy(alpha = 0.35f), Color.Transparent)
                        )
                    )
            )

            // Inner main circle
            Box(
                modifier = Modifier
                    .size(190.dp)
                    .scale(if (isBreathingActive && phase.startsWith("شَهِيق")) scaleAnim else 0.85f)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(EmeraldPrimaryDark, SkyTertiaryDark)
                        )
                    )
                    .border(2.dp, AmberSecondaryDark.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isBreathingActive) "$secondsInPhase" else "ابدأ",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }

        // Phase instruction display
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AmberSecondaryDark.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isBreathingActive) phase else "اضغط على الزر أدناه لبدء دورة التنفس والاسترخاء",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberSecondaryDark,
                    textAlign = TextAlign.Center
                )
                if (isBreathingActive) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الدورات المكتملة: $cycleCount • استشعر السكينة تسري في جسدك",
                        fontSize = 12.sp,
                        color = Color.White
                    )
                }
            }
        }

        // Action Button
        Button(
            onClick = {
                if (isBreathingActive) {
                    isBreathingActive = false
                } else {
                    cycleCount = 0
                    isBreathingActive = true
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isBreathingActive) RedEmergency else EmeraldPrimaryDark
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Icon(
                imageVector = if (isBreathingActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isBreathingActive) "إيقاف جلسة التنفس" else "بدء جلسة التنفس العميق",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
