package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ProfileEntity
import com.example.data.model.UserStatus
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedButton
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldContainerDark
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.RedEmergency

import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.AdminPanelSettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    profile: ProfileEntity,
    onUpdateStatus: (String) -> Unit,
    onUpdateName: (String) -> Unit,
    onUpdatePin: (String, Boolean) -> Unit,
    onUpdateReminders: (enabled: Boolean, morning: Boolean, evening: Boolean, lateNight: Boolean) -> Unit,
    onTestNotification: () -> Unit,
    onSignCovenant: (String) -> Unit,
    onNavigateToAdmin: () -> Unit,
    onBack: () -> Unit
) {
    var showNameDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showCovenantDialog by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }

    var draftName by remember(profile.userName) { mutableStateOf(profile.userName) }
    var draftPin by remember(profile.pinCode) { mutableStateOf(profile.pinCode) }
    var covenantSignName by remember { mutableStateOf(profile.userName) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الملف الشخصي والأمان", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("settings_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // User Profile Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldContainerDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = EmeraldPrimaryDark
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = profile.userName,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "المحارب البطل",
                                        fontSize = 12.sp,
                                        color = EmeraldPrimaryDark
                                    )
                                }
                            }

                            TextButton(onClick = { showNameDialog = true }) {
                                Text("تعديل الاسم")
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "الحالة الاجتماعية (لتخصيص توجيهات الكتاب):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            UserStatus.values().forEach { status ->
                                val isSelected = profile.userStatus == status.name
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (isSelected) EmeraldPrimaryDark else MaterialTheme.colorScheme.surface
                                        )
                                        .border(
                                            1.dp,
                                            if (isSelected) EmeraldPrimaryDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { onUpdateStatus(status.name) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = status.titleAr,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Security & PIN Lock Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = AmberSecondaryDark
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "قفل الخصوصية برقم سري (PIN)",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = if (profile.isPinEnabled) "مفعّل (الرمز: ****)" else "معطل حالياً",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = profile.isPinEnabled,
                                onCheckedChange = { isChecked ->
                                    if (isChecked && profile.pinCode.length < 4) {
                                        showPinDialog = true
                                    } else {
                                        onUpdatePin(profile.pinCode, isChecked)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimaryDark)
                            )
                        }

                        if (profile.isPinEnabled) {
                            Spacer(modifier = Modifier.height(10.dp))
                            TextButton(
                                onClick = { showPinDialog = true },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("تغيير الرمز السري")
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Offline Mode Notice
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = EmeraldPrimaryDark,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "الخصوصية التامة: يعمل التطبيق بالكامل بدون إنترنت (Offline 100%) لحفظ جميع بياناتك محلياً على جهازك دون مشاركة أي شيء.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            // Smart Reminders Card (التنبيهات والتذكيرات الذكية)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldContainerDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = null,
                                        tint = EmeraldPrimaryDark,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "التنبيهات والتذكيرات الذكية",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = if (profile.remindersEnabled) "مفعّلة وتعمل تلقائياً" else "معطلة",
                                        fontSize = 11.sp,
                                        color = if (profile.remindersEnabled) EmeraldPrimaryDark else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = profile.remindersEnabled,
                                onCheckedChange = { isChecked ->
                                    onUpdateReminders(
                                        isChecked,
                                        profile.morningReminderEnabled,
                                        profile.eveningReminderEnabled,
                                        profile.lateNightGuardEnabled
                                    )
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimaryDark)
                            )
                        }

                        if (profile.remindersEnabled) {
                            Spacer(modifier = Modifier.height(14.dp))

                            // Morning reminder toggle
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        onUpdateReminders(
                                            profile.remindersEnabled,
                                            !profile.morningReminderEnabled,
                                            profile.eveningReminderEnabled,
                                            profile.lateNightGuardEnabled
                                        )
                                    }
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "☀️ تذكير الصباح (برنامج الـ 40 يوماً)",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "الساعة 7:00 ص — ورد الصباح والدوش البارد والنية",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Checkbox(
                                    checked = profile.morningReminderEnabled,
                                    onCheckedChange = { chk ->
                                        onUpdateReminders(
                                            profile.remindersEnabled,
                                            chk,
                                            profile.eveningReminderEnabled,
                                            profile.lateNightGuardEnabled
                                        )
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimaryDark)
                                )
                            }

                            // Evening reminder toggle
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        onUpdateReminders(
                                            profile.remindersEnabled,
                                            profile.morningReminderEnabled,
                                            !profile.eveningReminderEnabled,
                                            profile.lateNightGuardEnabled
                                        )
                                    }
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "🌙 تذكير المساء والتقييم اليومي",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "الساعة 8:30 م — تقييم اليوم وتوكيدات العقل الباطن",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Checkbox(
                                    checked = profile.eveningReminderEnabled,
                                    onCheckedChange = { chk ->
                                        onUpdateReminders(
                                            profile.remindersEnabled,
                                            profile.morningReminderEnabled,
                                            chk,
                                            profile.lateNightGuardEnabled
                                        )
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimaryDark)
                                )
                            }

                            // Late Night Guard toggle
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        onUpdateReminders(
                                            profile.remindersEnabled,
                                            profile.morningReminderEnabled,
                                            profile.eveningReminderEnabled,
                                            !profile.lateNightGuardEnabled
                                        )
                                    }
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "🛡️ حارس الليل الوقائي (وقت الخطر)",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        color = RedEmergency
                                    )
                                    Text(
                                        text = "الساعة 11:30 م — تنبيه وقائي حاسم لإغلاق الهاتف",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Checkbox(
                                    checked = profile.lateNightGuardEnabled,
                                    onCheckedChange = { chk ->
                                        onUpdateReminders(
                                            profile.remindersEnabled,
                                            profile.morningReminderEnabled,
                                            profile.eveningReminderEnabled,
                                            chk
                                        )
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = RedEmergency)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Test notification button
                            OutlinedButton(
                                onClick = onTestNotification,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = AmberSecondaryDark,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "إرسال إشعار تحفيزي تجريبي الآن",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Covenant Section
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Draw,
                                contentDescription = null,
                                tint = AmberSecondaryDark
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "ميثاق العهد الأخير (الفصل الثاني عشر)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (profile.covenantSigned) {
                            Text(
                                text = "تم توقيع العهد مع الله بتاريخ: ${profile.covenantSignatureDate} بواسطة: ${profile.covenantSignatureName}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimaryDark
                            )
                        } else {
                            Text(
                                text = "لم توقع ميثاق العهد الأخير بعد. اقرأ العهد ووقعه لتعلن ولادة إنسان جديد لا يهزم.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { showCovenantDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberSecondaryDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (profile.covenantSigned) "عرض نص العهد الموقع" else "قراءة وتوقيع العهد",
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }
            }

            // Wallpaper Reminder Feature (Habit 20)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Smartphone,
                                contentDescription = null,
                                tint = EmeraldPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "شاشة التذكير الدائمة (العادة 20)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "العادة 20 في الكتاب تنص على جعل شاشة الجوال تذكيراً: 'أنا حر، لست عبداً لشهوتي'.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { showWallpaperDialog = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("عرض بطاقة التذكير بحجم كامل")
                        }
                    }
                }
            }

            // Admin Dashboard Entry
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AmberSecondaryDark.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AmberSecondaryDark.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = AmberSecondaryDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "لوحة تحكم المشرف (Admin Dashboard)",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AmberSecondaryDark
                                )
                                Text(
                                    text = "إضافة وتعديل وحذف فصول الكتاب ومهام الـ 40 يوماً",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onNavigateToAdmin,
                            colors = ButtonDefaults.buttonColors(containerColor = AmberSecondaryDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("open_admin_dashboard_button")
                        ) {
                            Text("دخول وضع المشرف بالرقم السري", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // About Book
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = EmeraldPrimaryDark)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "عن كتاب 'طريق التحرر من عبودية الوهم'",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "مرجع متكامل وشامل يجمع بين البصيرة الإيمانية العميقة، والحقائق العلمية العصبية، والخطط النفسية والرياضية لاستعادة هرمونات الرجولة، وبرنامج الـ 40 يوماً لبناء حياة العظماء.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }

    // Name Dialog
    if (showNameDialog) {
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("تعديل اسم المستخدم") },
            text = {
                OutlinedTextField(
                    value = draftName,
                    onValueChange = { draftName = it },
                    label = { Text("الاسم") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (draftName.isNotBlank()) {
                        onUpdateName(draftName.trim())
                    }
                    showNameDialog = false
                }) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNameDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // PIN Dialog
    if (showPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("تعيين الرمز السري (4 أرقام)") },
            text = {
                Column {
                    Text("أدخل 4 أرقام لقفل التطبيق والحفاظ على خصوصيتك:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                                pinInput = it
                                pinError = null
                            }
                        },
                        label = { Text("الرمز السري PIN") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError != null) {
                        Text(text = pinError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (pinInput.length == 4) {
                        onUpdatePin(pinInput, true)
                        showPinDialog = false
                    } else {
                        pinError = "يجب أن يتكون الرمز من 4 أرقام"
                    }
                }) {
                    Text("تأكيد وتفعيل")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Covenant Dialog
    if (showCovenantDialog) {
        AlertDialog(
            onDismissRequest = { showCovenantDialog = false },
            title = { Text("ميثاق العهد الأخير") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "« يا رب.. ها أنا أقف بين يديك الآن، لا متجملاً ولا متذرعاً بالأعذار. أعدك يا رب ألا أهرب منك بعد اليوم، وألا أساوم الشهوة ولا أجادلها، بل أفر بديني إليك فرار الصادقين. وأعاهدك أن أكرم هذا الجسد الذي ائتمنتني عليه، وألا أذله بمعصية. اللهم بدّل شهواتي طاعة، وغفلتي ذكراً، وانكساري قرباً »",
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = covenantSignName,
                        onValueChange = { covenantSignName = it },
                        label = { Text("اكتب اسمك لتوقيع العهد:") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (covenantSignName.isNotBlank()) {
                            onSignCovenant(covenantSignName.trim())
                            showCovenantDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberSecondaryDark)
                ) {
                    Text("أعاهد الله وأوقع العهد", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCovenantDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Wallpaper Reminder Dialog
    if (showWallpaperDialog) {
        AlertDialog(
            onDismissRequest = { showWallpaperDialog = false },
            title = { Text("تذكير العادة 20") },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .border(2.dp, AmberSecondaryDark, RoundedCornerShape(16.dp))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "أَنَا حُـرّ",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = AmberSecondaryDark
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "لَسْتُ عَبْـداً لِشَهْوَتِي",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لأنني عبد لله وحده",
                            fontSize = 14.sp,
                            color = EmeraldPrimaryDark
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showWallpaperDialog = false }) {
                    Text("تم الفهم")
                }
            }
        )
    }
}
