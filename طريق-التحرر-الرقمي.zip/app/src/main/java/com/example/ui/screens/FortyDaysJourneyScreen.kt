package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DailyRecordEntity
import com.example.data.model.HabitCategory
import com.example.data.repository.FortyDaysPlanDataSource
import com.example.data.repository.HabitsDataSource
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldContainerDark
import com.example.ui.theme.EmeraldPrimaryDark
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import com.example.data.repository.DailyJourneyPlan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FortyDaysJourneyScreen(
    currentDailyRecord: DailyRecordEntity,
    dailyPlans: List<DailyJourneyPlan> = emptyList(),
    onSaveDailyRecord: (DailyRecordEntity) -> Unit,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: جدول الأربعين يوماً, 1: مهام اليوم, 2: الامتنان, 3: التقييم المسائي
    var selectedDayNumber by remember { mutableIntStateOf(1) }

    val todayFormatted = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    var recordState by remember(currentDailyRecord) {
        mutableStateOf(currentDailyRecord)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("برنامج رحلة الـ 40 يوماً بالتفصيل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("اليوم $selectedDayNumber من 40 • $todayFormatted", style = MaterialTheme.typography.bodySmall, color = EmeraldPrimaryDark)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("خطة الـ 40 يوماً", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("مهام اليوم", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("الامتنان الصباحي", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("التقييم المسائي", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedTab) {
                0 -> DayByDayDetailTab(
                    selectedDay = selectedDayNumber,
                    onSelectDay = { selectedDayNumber = it }
                )
                1 -> DailyChecklistTab(
                    record = recordState,
                    dayNumber = selectedDayNumber,
                    onUpdate = { updated ->
                        recordState = updated
                        onSaveDailyRecord(updated)
                    }
                )
                2 -> MorningGratitudeTab(
                    record = recordState,
                    onUpdate = { updated ->
                        recordState = updated
                        onSaveDailyRecord(updated)
                    }
                )
                3 -> EveningEvaluationTab(
                    record = recordState,
                    onUpdate = { updated ->
                        recordState = updated
                        onSaveDailyRecord(updated)
                    }
                )
            }
        }
    }
}

@Composable
fun DayByDayDetailTab(
    selectedDay: Int,
    onSelectDay: (Int) -> Unit
) {
    val dayPlan = remember(selectedDay) {
        FortyDaysPlanDataSource.getDayPlan(selectedDay)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Horizontal Day Selector (1 to 40)
        item {
            Column {
                Text(
                    text = "اختر اليوم لاستعراض مهامه الخاصة:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items((1..40).toList()) { d ->
                        val isSelected = d == selectedDay
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSelected) EmeraldPrimaryDark else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) AmberSecondaryDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    CircleShape
                                )
                                .clickable { onSelectDay(d) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$d",
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Day Title & Motivational Quote
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AmberSecondaryDark.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dayPlan.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = AmberSecondaryDark
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(EmeraldContainerDark)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "اليوم $selectedDay / 40",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimaryDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = dayPlan.habitFocus,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "« ${dayPlan.motivationalQuote} »",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimaryDark,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Spiritual Task Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.WbSunny, contentDescription = null, tint = AmberSecondaryDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الورد الروحي لليوم $selectedDay:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = dayPlan.spiritualTask,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "📖 ${dayPlan.quranVerseOrHadith}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = EmeraldPrimaryDark
                    )
                }
            }
        }

        // Practical Action Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = EmeraldPrimaryDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "المهمة التطبيقية والسلوكية لليوم $selectedDay:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimaryDark
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = dayPlan.practicalTask,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Day-specific Subconscious Affirmation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldContainerDark.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تأكيد العقل الباطن الخاص باليوم $selectedDay:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimaryDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = dayPlan.dailyAffirmation,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Previous / Next Buttons
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (selectedDay > 1) {
                    OutlinedButton(
                        onClick = { onSelectDay(selectedDay - 1) },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اليوم السابق (${selectedDay - 1})")
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (selectedDay < 40) {
                    Button(
                        onClick = { onSelectDay(selectedDay + 1) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("اليوم التالي (${selectedDay + 1})")
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
fun DailyChecklistTab(
    record: DailyRecordEntity,
    dayNumber: Int,
    onUpdate: (DailyRecordEntity) -> Unit
) {
    val completedCount = listOf(
        record.morningAthkarDone,
        record.eveningAthkarDone,
        record.quranDone,
        record.prayersOnTime,
        record.coldShowerDone,
        record.workoutDone,
        record.screenLimitDone
    ).count { it }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "إنجاز مهام اليوم: $completedCount من 7",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "خطة اليوم $dayNumber من برنامج الـ 40 يوماً",
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldPrimaryDark
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (completedCount == 7) EmeraldPrimaryDark else AmberSecondaryDark.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${(completedCount * 100) / 7}%",
                            fontWeight = FontWeight.Bold,
                            color = if (completedCount == 7) Color.White else AmberSecondaryDark,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "قائمة المهام اليومية الموصى بها في الكتاب:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            ChecklistRowItem(
                title = "أذكار الصباح وسيد الاستغفار",
                subtitle = "العادة 1 و7: تحصين الروح وإعلان العهد النقي",
                isChecked = record.morningAthkarDone,
                onCheckedChange = { onUpdate(record.copy(morningAthkarDone = it)) }
            )
        }

        item {
            ChecklistRowItem(
                title = "المحافظة على الصلوات الخمس في وقتها",
                subtitle = "العادة 10: شريان النور وضبط الانضباط النفسي",
                isChecked = record.prayersOnTime,
                onCheckedChange = { onUpdate(record.copy(prayersOnTime = it)) }
            )
        }

        item {
            ChecklistRowItem(
                title = "قراءة 5 صفحات من القرآن بتدبر",
                subtitle = "العادة 8: نور القرآن يطرد ظلام الشهوة",
                isChecked = record.quranDone,
                onCheckedChange = { onUpdate(record.copy(quranDone = it)) }
            )
        }

        item {
            ChecklistRowItem(
                title = "حمام بارد صباحاً",
                subtitle = "العادة 23: لترويض النفس ورفع هرمونات القوة والانضباط",
                isChecked = record.coldShowerDone,
                onCheckedChange = { onUpdate(record.copy(coldShowerDone = it)) }
            )
        }

        item {
            ChecklistRowItem(
                title = "تمارين المقاومة والنشاط البدني",
                subtitle = "العادة 22 والفصل السابع: رفع التستوستيرون والمشي",
                isChecked = record.workoutDone,
                onCheckedChange = { onUpdate(record.copy(workoutDone = it)) }
            )
        }

        item {
            ChecklistRowItem(
                title = "أذكار المساء والاستغفار",
                subtitle = "العادة 7 و9: غسيل القلب قبل النوم",
                isChecked = record.eveningAthkarDone,
                onCheckedChange = { onUpdate(record.copy(eveningAthkarDone = it)) }
            )
        }

        item {
            ChecklistRowItem(
                title = "شحن الهاتف خارج غرفة النوم وترك الشاشات",
                subtitle = "العادة 13 و19: حماية الليل من فخاخ الضعف",
                isChecked = record.screenLimitDone,
                onCheckedChange = { onUpdate(record.copy(screenLimitDone = it)) }
            )
        }
    }
}

@Composable
fun ChecklistRowItem(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isChecked) EmeraldContainerDark.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!isChecked) }
            .border(
                1.dp,
                if (isChecked) EmeraldPrimaryDark else Color.Transparent,
                RoundedCornerShape(14.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isChecked,
                onCheckedChange = onCheckedChange,
                colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimaryDark)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun MorningGratitudeTab(
    record: DailyRecordEntity,
    onUpdate: (DailyRecordEntity) -> Unit
) {
    var g1 by remember(record.gratitude1) { mutableStateOf(record.gratitude1) }
    var g2 by remember(record.gratitude2) { mutableStateOf(record.gratitude2) }
    var g3 by remember(record.gratitude3) { mutableStateOf(record.gratitude3) }
    var isSaved by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.WbSunny, contentDescription = null, tint = AmberSecondaryDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تمرين الامتنان الصباحي (الفصل الثامن)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "اكتب 3 نعم أنعم الله بها عليك اليوم، وتأملها لثلاثين ثانية. بهذه الطريقة تعيد برمجة العقل الباطن على الامتنان والرضا والسيطرة، وتبدأ يومك في كنف الله.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = g1,
                onValueChange = { g1 = it; isSaved = false },
                label = { Text("النعمة الأولى:") },
                placeholder = { Text("مثال: نعمة البصر وسلامة الحواس، الاستيقاظ حياً...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            OutlinedTextField(
                value = g2,
                onValueChange = { g2 = it; isSaved = false },
                label = { Text("النعمة الثانية:") },
                placeholder = { Text("مثال: نعمة الهداية والفرصة الجديدة، الصحة...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            OutlinedTextField(
                value = g3,
                onValueChange = { g3 = it; isSaved = false },
                label = { Text("النعمة الثالثة:") },
                placeholder = { Text("مثال: نعمة الأهل، المسجد، كوب الماء العذب...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Button(
                onClick = {
                    onUpdate(record.copy(gratitude1 = g1, gratitude2 = g2, gratitude3 = g3))
                    isSaved = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSaved) "تم حفظ النعم بنجاح ✓" else "حفظ نعم اليوم",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun EveningEvaluationTab(
    record: DailyRecordEntity,
    onUpdate: (DailyRecordEntity) -> Unit
) {
    var rating by remember(record.eveningRating) { mutableIntStateOf(record.eveningRating) }
    var notes by remember(record.eveningReflection) { mutableStateOf(record.eveningReflection) }
    var affirmationChecked by remember(record.subconsciousAffirmationRead) {
        mutableStateOf(record.subconsciousAffirmationRead)
    }
    var isSaved by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Nightlight, contentDescription = null, tint = AmberSecondaryDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "جلسة التقييم المسائي الـ 10 دقائق (الفصل الثامن)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "قبل النوم: أغلق هاتفك واجلس في مكان هادئ وتحدث مع نفسك بصدق: ماذا فعلت اليوم؟ هل ارتفعت أم ضعفت؟ هل حفظت نظري وعهدي؟",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Text(
                text = "تقييم ثباتك وانضباطك اليوم:",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                for (star in 1..5) {
                    IconButton(onClick = {
                        rating = star
                        isSaved = false
                    }) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "نجمة $star",
                            tint = if (star <= rating) AmberSecondaryDark else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it; isSaved = false },
                label = { Text("محاسبة النفس ودروس اليوم:") },
                placeholder = { Text("ما الأعمال الإيجابية التي فعلتها؟ ما المواقف التي قاومت فيها؟ ما الذي سأغيره غداً؟") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldContainerDark.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🧠 تأكيد العقل الباطن قبل النوم:",
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimaryDark,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "« أنا رجل نقي القلب، قوي بالله، لست عبداً لشهوتي ولن يقيدني ذنب قديم. غداً فجر جديد وقوة أكبر بإذن الله »",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            affirmationChecked = !affirmationChecked
                            isSaved = false
                        }
                    ) {
                        Checkbox(
                            checked = affirmationChecked,
                            onCheckedChange = { affirmationChecked = it; isSaved = false },
                            colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimaryDark)
                        )
                        Text(
                            text = "قرأت التأكيد بقلب حاضر وتنفست بعمق",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    onUpdate(
                        record.copy(
                            eveningRating = rating,
                            eveningReflection = notes,
                            subconsciousAffirmationRead = affirmationChecked
                        )
                    )
                    isSaved = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSaved) "تم حفظ التقييم المسائي ✓" else "حفظ التقييم المسائي",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
