package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.DailyRecordEntity
import com.example.data.local.JournalEntryEntity
import com.example.data.local.ProfileEntity
import com.example.data.model.BookChapter
import com.example.data.repository.DailyJourneyPlan
import com.example.data.repository.RecoveryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecoveryViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = RecoveryRepository(database.recoveryDao())

    val profileState: StateFlow<ProfileEntity> = repository.getProfileFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ProfileEntity()
        )

    val chaptersState: StateFlow<List<BookChapter>> = repository.getAllChaptersFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val dailyPlansState: StateFlow<List<DailyJourneyPlan>> = repository.getAllDailyPlansFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val journalEntriesState: StateFlow<List<JournalEntryEntity>> = repository.getAllJournalEntries()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val bookmarksState: StateFlow<List<BookmarkEntity>> = repository.getAllBookmarks()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val todayDateKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private val _todayRecordState = MutableStateFlow(DailyRecordEntity(dateKey = todayDateKey))
    val todayRecordState: StateFlow<DailyRecordEntity> = _todayRecordState.asStateFlow()

    private val _isAppUnlocked = MutableStateFlow(false)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty(application)
            repository.getDailyRecordFlow(todayDateKey).collect { record ->
                if (record != null) {
                    _todayRecordState.value = record
                }
            }
        }
    }

    fun unlockApp() {
        _isAppUnlocked.value = true
    }

    // Admin & Book operations
    fun saveChapter(chapter: BookChapter) {
        viewModelScope.launch {
            repository.saveChapter(chapter)
        }
    }

    fun deleteChapter(chapterId: Int) {
        viewModelScope.launch {
            repository.deleteChapter(chapterId)
        }
    }

    fun resetChaptersToDefault() {
        viewModelScope.launch {
            repository.resetChaptersToDefault(getApplication())
        }
    }

    fun saveDailyPlan(plan: DailyJourneyPlan) {
        viewModelScope.launch {
            repository.saveDailyPlan(plan)
        }
    }

    fun resetDailyPlansToDefault() {
        viewModelScope.launch {
            repository.resetDailyPlansToDefault()
        }
    }

    fun updateAdminPin(newPin: String) {
        viewModelScope.launch {
            repository.updateAdminPin(newPin)
        }
    }

    fun updateUserStatus(status: String) {
        viewModelScope.launch {
            repository.updateUserStatus(status)
        }
    }

    fun updateUserName(name: String) {
        viewModelScope.launch {
            repository.updateUserName(name)
        }
    }

    fun updatePin(pin: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.updatePin(pin, enabled)
            if (enabled) {
                _isAppUnlocked.value = true
            }
        }
    }

    fun signCovenant(name: String) {
        viewModelScope.launch {
            repository.signCovenant(name)
        }
    }

    fun resetStreak(trigger: String, feelings: String, lesson: String) {
        viewModelScope.launch {
            repository.resetStreak(trigger, feelings, lesson)
        }
    }

    fun logVictory(title: String, trigger: String, feelings: String, action: String) {
        viewModelScope.launch {
            repository.recordVictory(title, trigger, feelings, action)
        }
    }

    fun deleteJournalEntry(entry: JournalEntryEntity) {
        viewModelScope.launch {
            repository.deleteJournalEntry(entry)
        }
    }

    fun saveDailyRecord(record: DailyRecordEntity) {
        viewModelScope.launch {
            _todayRecordState.value = record
            repository.upsertDailyRecord(record)
        }
    }

    fun addBookmark(chapterId: Int, chapterTitle: String, sectionTitle: String, excerpt: String, note: String) {
        viewModelScope.launch {
            repository.addBookmark(chapterId, chapterTitle, sectionTitle, excerpt, note)
        }
    }

    fun deleteBookmark(bookmark: BookmarkEntity) {
        viewModelScope.launch {
            repository.deleteBookmark(bookmark)
        }
    }

    // Reminders settings
    fun updateReminderSettings(enabled: Boolean, morning: Boolean, evening: Boolean, lateNight: Boolean) {
        viewModelScope.launch {
            repository.updateReminderSettings(enabled, morning, evening, lateNight)
            val context = getApplication<Application>()
            if (enabled) {
                com.example.service.ReminderScheduler.scheduleAllReminders(
                    context = context,
                    morningEnabled = morning,
                    eveningEnabled = evening,
                    lateNightEnabled = lateNight
                )
            } else {
                com.example.service.ReminderScheduler.cancelAll(context)
            }
        }
    }

    fun sendTestMotivationalNotification() {
        val context = getApplication<Application>()
        com.example.service.ReminderScheduler.triggerInstantMotivationalNotification(context)
    }

    // Detox tracking
    fun recordCompletedDetox(minutes: Int) {
        viewModelScope.launch {
            repository.recordCompletedDetox(minutes)
        }
    }
}

