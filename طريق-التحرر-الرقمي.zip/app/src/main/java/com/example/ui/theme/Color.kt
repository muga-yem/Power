package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val EmeraldPrimaryLight = Color(0xFF0F766E)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFCCFBF1)
val EmeraldOnContainerLight = Color(0xFF115E59)

val AmberSecondaryLight = Color(0xFFD97706)
val AmberOnSecondaryLight = Color(0xFFFFFFFF)
val AmberContainerLight = Color(0xFFFEF3C7)
val AmberOnContainerLight = Color(0xFF78350F)

val SkyTertiaryLight = Color(0xFF0284C7)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnBackgroundLight = Color(0xFF0F172A)
val OnSurfaceLight = Color(0xFF1E293B)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Palette (Calm, Serene Midnight Slate)
val EmeraldPrimaryDark = Color(0xFF14B8A6)
val EmeraldOnPrimaryDark = Color(0xFF042F2E)
val EmeraldContainerDark = Color(0xFF134E4A)
val EmeraldOnContainerDark = Color(0xFFCCFBF1)

val AmberSecondaryDark = Color(0xFFFBBF24)
val AmberOnSecondaryDark = Color(0xFF451A03)
val AmberContainerDark = Color(0xFF78350F)
val AmberOnContainerDark = Color(0xFFFEF3C7)

val SkyTertiaryDark = Color(0xFF38BDF8)
val BackgroundDark = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnBackgroundDark = Color(0xFFF1F5F9)
val OnSurfaceDark = Color(0xFFE2E8F0)
val OutlineDark = Color(0xFF334155)

// Special Accents
val RedEmergency = Color(0xFFDC2626)
val GreenSuccess = Color(0xFF16A34A)
val GoldAccent = Color(0xFFF59E0B)
val CardBorderDark = Color(0xFF243049)
