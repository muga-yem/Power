package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookmarkEntity
import com.example.data.model.BookChapter
import com.example.data.model.ChapterSection
import com.example.data.repository.BookRepository
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldContainerDark
import com.example.ui.theme.EmeraldPrimaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookReaderScreen(
    initialChapterId: Int = 0,
    chapters: List<BookChapter> = emptyList(),
    bookmarks: List<BookmarkEntity>,
    onAddBookmark: (Int, String, String, String, String) -> Unit,
    onDeleteBookmark: (BookmarkEntity) -> Unit,
    onBack: () -> Unit
) {
    val effectiveChapters = if (chapters.isNotEmpty()) chapters else BookRepository.allChapters
    var selectedChapterId by remember { mutableIntStateOf(initialChapterId) }
    var selectedSectionIndex by remember { mutableIntStateOf(0) }
    var isPaginationMode by remember { mutableStateOf(false) } // False = Continuous Scroll, True = Section-by-Section Pagination

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var fontScale by remember { mutableFloatStateOf(1.0f) }
    var showBookmarksDialog by remember { mutableStateOf(false) }
    var showChapterPickerModal by remember { mutableStateOf(false) }

    var bookmarkDraftSection by remember { mutableStateOf<ChapterSection?>(null) }
    var bookmarkDraftNote by remember { mutableStateOf("") }

    val currentChapter = remember(selectedChapterId, effectiveChapters) {
        effectiveChapters.find { it.id == selectedChapterId } ?: effectiveChapters.first()
    }

    val searchResults = remember(searchQuery, effectiveChapters) {
        if (searchQuery.isBlank()) emptyList() else {
            val q = searchQuery.trim().lowercase()
            val list = mutableListOf<BookRepository.SearchResult>()
            for (ch in effectiveChapters) {
                for (sec in ch.sections) {
                    val pMatch = sec.paragraphs.firstOrNull { it.lowercase().contains(q) }
                        ?: sec.quranOrHadith.firstOrNull { it.lowercase().contains(q) }
                        ?: if (sec.title.lowercase().contains(q)) sec.paragraphs.firstOrNull() else null
                    if (pMatch != null) {
                        val sIdx = pMatch.lowercase().indexOf(q).coerceAtLeast(0)
                        val snipStart = (sIdx - 30).coerceAtLeast(0)
                        val snipEnd = (sIdx + q.length + 50).coerceAtMost(pMatch.length)
                        list.add(BookRepository.SearchResult(ch, sec, "..." + pMatch.substring(snipStart, snipEnd).trim() + "..."))
                    }
                }
            }
            list
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("ابحث في كامل نصوص الكتاب...") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("book_search_field")
                        )
                    } else {
                        Column(modifier = Modifier.clickable { showChapterPickerModal = true }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentChapter.numberTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "▾",
                                    fontSize = 14.sp,
                                    color = AmberSecondaryDark
                                )
                            }
                            Text(
                                text = currentChapter.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (isSearchActive) {
                            isSearchActive = false
                            searchQuery = ""
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    // Search toggle
                    IconButton(onClick = {
                        isSearchActive = !isSearchActive
                        if (!isSearchActive) searchQuery = ""
                    }) {
                        Icon(
                            imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                            contentDescription = "بحث"
                        )
                    }

                    // Mode toggle (Scroll vs Pagination)
                    IconButton(onClick = { isPaginationMode = !isPaginationMode }) {
                        Icon(
                            imageVector = if (isPaginationMode) Icons.Default.FormatListNumbered else Icons.Default.SwapHoriz,
                            contentDescription = "تبديل نمط التصفح (صفحات / مستمر)",
                            tint = if (isPaginationMode) AmberSecondaryDark else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Font size adjustments
                    IconButton(onClick = {
                        fontScale = if (fontScale >= 1.35f) 0.9f else fontScale + 0.15f
                    }) {
                        Icon(imageVector = Icons.Default.FormatSize, contentDescription = "تكبير/تصغير الخط")
                    }

                    // Bookmarks list dialog
                    IconButton(onClick = { showBookmarksDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "العلامات المرجعية",
                            tint = if (bookmarks.isNotEmpty()) AmberSecondaryDark else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Horizontal Chapter Selector Bar
            if (!isSearchActive) {
                ScrollableTabRow(
                    selectedTabIndex = selectedChapterId.coerceIn(0, (effectiveChapters.size - 1).coerceAtLeast(0)),
                    edgePadding = 12.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    effectiveChapters.forEach { ch ->
                        Tab(
                            selected = selectedChapterId == ch.id,
                            onClick = {
                                selectedChapterId = ch.id
                                selectedSectionIndex = 0
                            },
                            text = {
                                Text(
                                    text = ch.numberTitle,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedChapterId == ch.id) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }
            }

            // Body Content: Search Results OR Reading View
            if (isSearchActive && searchQuery.isNotBlank()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = "نتائج البحث (${searchResults.size}):",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(searchResults) { result ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedChapterId = result.chapter.id
                                    val idx = result.chapter.sections.indexOfFirst { it.id == result.section.id }
                                    selectedSectionIndex = if (idx >= 0) idx else 0
                                    isSearchActive = false
                                    searchQuery = ""
                                }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "${result.chapter.numberTitle}: ${result.section.title}",
                                    fontWeight = FontWeight.Bold,
                                    color = AmberSecondaryDark,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = result.matchedSnippet,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            } else if (isPaginationMode && currentChapter.sections.isNotEmpty()) {
                // SECTION-BY-SECTION PAGINATION MODE
                val currentSection = currentChapter.sections.getOrElse(selectedSectionIndex) { currentChapter.sections.first() }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Page indicator bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نمط الصفحات • المقطع ${selectedSectionIndex + 1} من ${currentChapter.sections.size}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimaryDark
                        )
                        Text(
                            text = currentChapter.numberTitle,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            SectionReaderItem(
                                section = currentSection,
                                fontScale = fontScale,
                                onBookmark = {
                                    bookmarkDraftSection = currentSection
                                    bookmarkDraftNote = ""
                                }
                            )
                        }
                    }

                    // Bottom Pagination Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (selectedSectionIndex > 0) {
                                    selectedSectionIndex -= 1
                                } else if (selectedChapterId > 0) {
                                    selectedChapterId -= 1
                                    selectedSectionIndex = 0
                                }
                            },
                            enabled = selectedSectionIndex > 0 || selectedChapterId > 0,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("السابق")
                        }

                        Text(
                            text = "${selectedSectionIndex + 1} / ${currentChapter.sections.size}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )

                        Button(
                            onClick = {
                                if (selectedSectionIndex < currentChapter.sections.size - 1) {
                                    selectedSectionIndex += 1
                                } else if (selectedChapterId < effectiveChapters.size - 1) {
                                    selectedChapterId += 1
                                    selectedSectionIndex = 0
                                }
                            },
                            enabled = selectedSectionIndex < currentChapter.sections.size - 1 || selectedChapterId < effectiveChapters.size - 1,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("التالي")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                        }
                    }
                }
            } else {
                // CONTINUOUS SCROLL MODE
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Chapter Title Banner
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = currentChapter.numberTitle,
                                    fontSize = (14 * fontScale).sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberSecondaryDark
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentChapter.title,
                                    fontSize = (20 * fontScale).sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentChapter.subtitle,
                                    fontSize = (13 * fontScale).sp,
                                    color = EmeraldPrimaryDark,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = currentChapter.summary,
                                    fontSize = (12 * fontScale).sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Chapter Sections
                    items(currentChapter.sections) { section ->
                        SectionReaderItem(
                            section = section,
                            fontScale = fontScale,
                            onBookmark = {
                                bookmarkDraftSection = section
                                bookmarkDraftNote = ""
                            }
                        )
                    }

                    // Bottom Navigation between chapters
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (selectedChapterId > 0) {
                                Button(
                                    onClick = {
                                        selectedChapterId -= 1
                                        selectedSectionIndex = 0
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("الفصل السابق")
                                }
                            } else {
                                Spacer(modifier = Modifier.width(1.dp))
                            }

                            if (selectedChapterId < effectiveChapters.size - 1) {
                                Button(
                                    onClick = {
                                        selectedChapterId += 1
                                        selectedSectionIndex = 0
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("الفصل التالي")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Quick Chapter Picker Dialog
    if (showChapterPickerModal) {
        AlertDialog(
            onDismissRequest = { showChapterPickerModal = false },
            title = { Text("فهرس فصول الكتاب") },
            text = {
                LazyColumn(
                    modifier = Modifier.height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(effectiveChapters) { ch ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedChapterId == ch.id) EmeraldContainerDark.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedChapterId = ch.id
                                    selectedSectionIndex = 0
                                    showChapterPickerModal = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ch.numberTitle,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = AmberSecondaryDark,
                                    modifier = Modifier.width(75.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = ch.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = ch.subtitle,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChapterPickerModal = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Add Bookmark Dialog
    if (bookmarkDraftSection != null) {
        AlertDialog(
            onDismissRequest = { bookmarkDraftSection = null },
            title = { Text("حفظ علامة مرجعية وملاحظة") },
            text = {
                Column {
                    Text(
                        text = "القسم: ${bookmarkDraftSection!!.title}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = bookmarkDraftNote,
                        onValueChange = { bookmarkDraftNote = it },
                        placeholder = { Text("اكتب خاطرة أو ملاحظة شخصية على هذا المقطع...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val snippet = bookmarkDraftSection!!.paragraphs.firstOrNull() ?: ""
                    onAddBookmark(
                        currentChapter.id,
                        currentChapter.title,
                        bookmarkDraftSection!!.title,
                        snippet.take(120),
                        bookmarkDraftNote
                    )
                    bookmarkDraftSection = null
                }) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { bookmarkDraftSection = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Bookmarks List Dialog
    if (showBookmarksDialog) {
        AlertDialog(
            onDismissRequest = { showBookmarksDialog = false },
            title = { Text("العلامات المرجعية المحفوظة (${bookmarks.size})") },
            text = {
                if (bookmarks.isEmpty()) {
                    Text("لم تحفظ أي علامات مرجعية بعد. اضغط على أيقونة الإشارة المرجعية داخل أي مقطع لحفظه.")
                } else {
                    LazyColumn(
                        modifier = Modifier.height(300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(bookmarks) { bm ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = bm.chapterTitle,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = AmberSecondaryDark
                                        )
                                        IconButton(
                                            onClick = { onDeleteBookmark(bm) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "حذف العلامة",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = bm.sectionTitle,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        color = EmeraldPrimaryDark
                                    )
                                    Text(
                                        text = "« ${bm.excerptText} »",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (bm.personalNote.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "ملاحظتك: ${bm.personalNote}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            selectedChapterId = bm.chapterId
                                            showBookmarksDialog = false
                                        },
                                        modifier = Modifier.align(Alignment.End),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("انتقل للفصل", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBookmarksDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
fun SectionReaderItem(
    section: ChapterSection,
    fontScale: Float,
    onBookmark: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = section.title,
                    fontSize = (16 * fontScale).sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimaryDark,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onBookmark) {
                    Icon(
                        imageVector = Icons.Default.BookmarkBorder,
                        contentDescription = "حفظ علامة",
                        tint = AmberSecondaryDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            section.paragraphs.forEach { p ->
                Text(
                    text = p,
                    fontSize = (14 * fontScale).sp,
                    lineHeight = (22 * fontScale).sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            if (section.quranOrHadith.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                section.quranOrHadith.forEach { quote ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AmberSecondaryDark.copy(alpha = 0.12f))
                            .border(1.dp, AmberSecondaryDark.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = quote,
                            fontSize = (14 * fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark,
                            lineHeight = (22 * fontScale).sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            if (section.scientificNote != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF38BDF8).copy(alpha = 0.12f))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "🔬 حقيقة علمية ونفسية:",
                            fontSize = (12 * fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0284C7)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = section.scientificNote,
                            fontSize = (13 * fontScale).sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (section.keyTakeaway != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(EmeraldContainerDark.copy(alpha = 0.3f))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "💡 خلاصة للعمل والهمة:",
                            fontSize = (12 * fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = section.keyTakeaway,
                            fontSize = (13 * fontScale).sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
