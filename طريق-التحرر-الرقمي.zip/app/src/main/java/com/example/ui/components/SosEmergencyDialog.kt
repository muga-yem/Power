package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.RedEmergency
import kotlinx.coroutines.delay

@Composable
fun SosEmergencyDialog(
    onDismiss: () -> Unit,
    onUrgeOvercome: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: تنفس تهدئي, 1: أسئلة قاطعة للوهم, 2: إجراءات فورية, 3: أدعية النجاة

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp)
                .clip(RoundedCornerShape(24.dp))
                .border(2.dp, RedEmergency, RoundedCornerShape(24.dp))
                .testTag("sos_emergency_dialog"),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("sos_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق نافذة الطوارئ",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "تدخل الطوارئ الفوري (SOS)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = RedEmergency
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = RedEmergency
                        )
                    }
                }

                Text(
                    text = "توقف ثانية واحدة! لا تلمس شيئاً، ولا تصدق كذبة عقلك الآن. الرغبة موجة ستنكسر في دقائق.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("تنفس تهدئي", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("قطع الوهم", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("إجراءات سريعة", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("أدعية النجاة", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (selectedTab) {
                    0 -> BreathingExerciseSection()
                    1 -> CuttingIllusionQuestionsSection()
                    2 -> ImmediateActionsSection()
                    3 -> EmergencyPrayersSection()
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Bottom Action Button
                Button(
                    onClick = {
                        onUrgeOvercome()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("sos_victory_button")
                ) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الحمد لله.. تجاوزت الرغبة ولم أسقط!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BreathingExerciseSection() {
    var phaseIndex by remember { mutableIntStateOf(0) }
    var secondsLeft by remember { mutableIntStateOf(4) }

    val phases = listOf(
        Triple("شَـهِـيـق عـمـيـق من الأنف", 4, EmeraldPrimaryDark),
        Triple("احـبِـس النـفَـس واثـبُـت", 7, AmberSecondaryDark),
        Triple("زَفِـيـر هـادئ بـبـطء من الفم", 8, Color(0xFF38BDF8))
    )

    LaunchedEffect(phaseIndex, secondsLeft) {
        if (secondsLeft > 1) {
            delay(1000)
            secondsLeft -= 1
        } else {
            delay(1000)
            phaseIndex = (phaseIndex + 1) % phases.size
            secondsLeft = phases[phaseIndex].second
        }
    }

    val currentPhase = phases[phaseIndex]

    val transition = rememberInfiniteTransition(label = "breathing")
    val scale by transition.animateFloat(
        initialValue = if (phaseIndex == 0) 0.85f else 1.15f,
        targetValue = if (phaseIndex == 0) 1.25f else 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(currentPhase.second * 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "circle_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "تمرين التنفس 4-7-8 لتهدئة الجهاز العصبي فوراً",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(170.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            currentPhase.third.copy(alpha = 0.4f),
                            currentPhase.third.copy(alpha = 0.1f)
                        )
                    )
                )
                .border(3.dp, currentPhase.third, CircleShape)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$secondsLeft",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = currentPhase.third
                )
                Text(
                    text = "ثوانٍ",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = currentPhase.first,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = currentPhase.third,
            textAlign = TextAlign.Center
        )

        Text(
            text = "ركز فقط على حركة الهواء داخل صدرك. أنت تتحكم في نبضك وأعصابك الآن.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun CuttingIllusionQuestionsSection() {
    val questions = listOf(
        "يا نفس.. أيسرك لو أن ملك الموت جاءك الآن ليقبض روحك أن تكون هذه خاتمتك؟",
        "أيسرك لو أنك في القبر وجاء الملكان للسؤال أن تكون هذه بضاعتك بين يدي الله؟",
        "أيسرك عند الميزان وترجيح الحسنات والسيئات أن ترجح هذه اللحظة الرخيصة سيئاتك؟",
        "أيسرك وأنت تجوز الصراط كالبرق الخاطف أن تسقط في النار بسبب شهوة عابرة؟",
        "هل اللذة التي وعدتك بها الشاشة أعطتك شيئاً غير الندم والكسار والذل؟",
        "إنها كالماء المالح.. كلما شربت منها زاد عطشك واستنزاف طاقتك!"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "أسئلة الكتاب القاطعة للوهم (الفصل السادس):",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        questions.forEachIndexed { index, q ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "•",
                        color = AmberSecondaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(
                        text = q,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun ImmediateActionsSection() {
    val actions = listOf(
        Pair("غيّر مكانك فوراً", "اخرج من غرفتك، افتح الباب، اذهب إلى الصالة أو الشارع، لا تبق وحيداً في الخلوة أبداً."),
        Pair("اغسل وجهك بالماء البارد المثلج", "الماء البارد يكسر التفاعل العصبي الفوري ويصدم مستقبلات التوتر في الدماغ."),
        Pair("توضأ بسبوغ وصلّ ركعتين", "الوضوء يطفئ نار الشهوة ويهدئ نبضات القلب ويعيدك لكنف الله."),
        Pair("ضع الهاتف في غرفة أخرى", "افصل الشاحن والإنترنت واجعل بينك وبين الشاشة حاجزاً مادياً حقيقياً."),
        Pair("اتصل بصديق صالح أو تحدث مع أهلك", "10 دقائق من الحديث المباشر تكسر العزلة وتعيد عقلك إلى الواقع.")
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "خطوات الإنقاذ العملية الخمس (الفصل السادس):",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        actions.forEachIndexed { idx, item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "${idx + 1}. ${item.first}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.second,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun EmergencyPrayersSection() {
    val prayers = listOf(
        Pair("دعاء النبي ﷺ للشاب:", "«اللهم اغفر ذنبي، وطهر قلبي، وحصن فرجي»"),
        Pair("دعاء الاستغاثة والافتقار:", "«يا حي يا قيوم برحمتك أستغيث، أصلح لي شأني كله ولا تكلني إلى نفسي طرفة عين»"),
        Pair("دعاء السجود الخاشع:", "«اللهم إني أبرأ إليك من حولي وقوتي وألجأ إلى حولك وقوتك، اللهم أعني ولا تعن علي، وانصرني ولا تنصر علي»"),
        Pair("دعاء يوسف عليه السلام:", "«مَعَاذَ اللَّهِ إِنَّهُ رَبِّي أَحْسَنَ مَثْوَايَ»")
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "أدعية النجاة والتحصين من الكتاب:",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        prayers.forEach { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = item.first,
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberSecondaryDark,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = item.second,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
