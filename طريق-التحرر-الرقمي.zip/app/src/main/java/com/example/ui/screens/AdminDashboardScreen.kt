package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ProfileEntity
import com.example.data.model.BookChapter
import com.example.data.model.ChapterSection
import com.example.data.repository.DailyJourneyPlan
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldContainerDark
import com.example.ui.theme.EmeraldPrimaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    profile: ProfileEntity,
    chapters: List<BookChapter>,
    dailyPlans: List<DailyJourneyPlan>,
    onSaveChapter: (BookChapter) -> Unit,
    onDeleteChapter: (Int) -> Unit,
    onResetChapters: () -> Unit,
    onSaveDailyPlan: (DailyJourneyPlan) -> Unit,
    onResetDailyPlans: () -> Unit,
    onUpdateAdminPin: (String) -> Unit,
    onBack: () -> Unit
) {
    var isAuthenticated by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: فصول الكتاب, 1: مهام الـ 40 يوماً, 2: أمان المشرف

    var editingChapter by remember { mutableStateOf<BookChapter?>(null) }
    var isCreatingNewChapter by remember { mutableStateOf(false) }
    var deletingChapterId by remember { mutableStateOf<Int?>(null) }

    var editingDailyPlan by remember { mutableStateOf<DailyJourneyPlan?>(null) }

    // Admin PIN gate
    if (!isAuthenticated) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("تسجيل دخول المشرف") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }
                    }
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(AmberSecondaryDark.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = AmberSecondaryDark,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "لوحة تحكم المشرف",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "أدخل رمز PIN المشرف (الافتراضي: 9999)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = enteredPin,
                            onValueChange = {
                                if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                    enteredPin = it
                                    pinError = null
                                }
                            },
                            label = { Text("رمز PIN المشرف") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (pinError != null) {
                            Text(
                                text = pinError!!,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                if (enteredPin == profile.adminPinCode) {
                                    isAuthenticated = true
                                } else {
                                    pinError = "الرمز غير صحيح، حاول مرة أخرى"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_login_button")
                        ) {
                            Text("دخول إلى لوحة التحكم", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    // Authenticated Admin Dashboard
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("لوحة تحكم المشرف (Admin)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("إدارة فصول الكتاب وبرنامج الـ 40 يوماً", style = MaterialTheme.typography.bodySmall, color = AmberSecondaryDark)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = {
                        val nextId = (chapters.maxOfOrNull { it.id } ?: 0) + 1
                        editingChapter = BookChapter(
                            id = nextId,
                            numberTitle = "الفصل $nextId",
                            title = "",
                            subtitle = "",
                            summary = "",
                            sections = listOf(
                                ChapterSection(
                                    id = "sec_${nextId}_1",
                                    title = "المبحث الأول",
                                    paragraphs = listOf(""),
                                    quranOrHadith = emptyList(),
                                    scientificNote = null,
                                    keyTakeaway = null
                                )
                            )
                        )
                        isCreatingNewChapter = true
                    },
                    containerColor = EmeraldPrimaryDark,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("admin_add_chapter_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة فصل جديد")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("فصول الكتاب (${chapters.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("مهام الـ 40 يوماً (${dailyPlans.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("أمان المشرف", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedTab) {
                0 -> AdminChaptersTab(
                    chapters = chapters,
                    onEditChapter = { ch ->
                        editingChapter = ch
                        isCreatingNewChapter = false
                    },
                    onDeleteChapter = { chId -> deletingChapterId = chId }
                )
                1 -> AdminDailyPlansTab(
                    plans = dailyPlans,
                    onEditPlan = { plan -> editingDailyPlan = plan }
                )
                2 -> AdminSecurityTab(
                    currentPin = profile.adminPinCode,
                    onUpdatePin = onUpdateAdminPin,
                    onResetChapters = onResetChapters,
                    onResetDailyPlans = onResetDailyPlans
                )
            }
        }
    }

    // Edit/Create Chapter Dialog
    if (editingChapter != null) {
        ChapterEditorDialog(
            chapter = editingChapter!!,
            isNew = isCreatingNewChapter,
            onDismiss = {
                editingChapter = null
                isCreatingNewChapter = false
            },
            onSave = { savedChapter ->
                onSaveChapter(savedChapter)
                editingChapter = null
                isCreatingNewChapter = false
            }
        )
    }

    // Confirm Delete Chapter Dialog
    if (deletingChapterId != null) {
        AlertDialog(
            onDismissRequest = { deletingChapterId = null },
            title = { Text("تأكيد حذف الفصل") },
            text = { Text("هل أنت متأكد من حذف هذا الفصل نهائياً من قاعدة البيانات المحلية؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteChapter(deletingChapterId!!)
                        deletingChapterId = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingChapterId = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Edit Daily Plan Dialog
    if (editingDailyPlan != null) {
        DailyPlanEditorDialog(
            plan = editingDailyPlan!!,
            onDismiss = { editingDailyPlan = null },
            onSave = { savedPlan ->
                onSaveDailyPlan(savedPlan)
                editingDailyPlan = null
            }
        )
    }
}

@Composable
fun AdminChaptersTab(
    chapters: List<BookChapter>,
    onEditChapter: (BookChapter) -> Unit,
    onDeleteChapter: (Int) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldContainerDark.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.MenuBook, contentDescription = null, tint = EmeraldPrimaryDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "يمكنك إضافة فصول جديدة وتعديل نصوصها أو حذفها وسيتم الحفظ محلياً فوراً.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        items(chapters) { chapter ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${chapter.numberTitle}: ${chapter.title}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${chapter.sections.size} مباحث / مقاطع • ${chapter.subtitle}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row {
                        IconButton(onClick = { onEditChapter(chapter) }) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = EmeraldPrimaryDark)
                        }
                        IconButton(onClick = { onDeleteChapter(chapter.id) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterEditorDialog(
    chapter: BookChapter,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (BookChapter) -> Unit
) {
    var id by remember { mutableIntStateOf(chapter.id) }
    var numberTitle by remember { mutableStateOf(chapter.numberTitle) }
    var title by remember { mutableStateOf(chapter.title) }
    var subtitle by remember { mutableStateOf(chapter.subtitle) }
    var summary by remember { mutableStateOf(chapter.summary) }

    // Section 1
    val firstSec = chapter.sections.firstOrNull()
    var secTitle by remember { mutableStateOf(firstSec?.title ?: "المبحث الأول") }
    var secParagraphsText by remember { mutableStateOf(firstSec?.paragraphs?.joinToString("\n\n") ?: "") }
    var secQuotesText by remember { mutableStateOf(firstSec?.quranOrHadith?.joinToString("\n") ?: "") }
    var secScience by remember { mutableStateOf(firstSec?.scientificNote ?: "") }
    var secKeyTakeaway by remember { mutableStateOf(firstSec?.keyTakeaway ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isNew) "إضافة فصل جديد للكتاب" else "تعديل الفصل ${chapter.numberTitle}", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = numberTitle,
                    onValueChange = { numberTitle = it },
                    label = { Text("عنوان الترقيم (مثال: الفصل الأول)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الفصل الرئيسي") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text("العنوان الفرعي") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = summary,
                    onValueChange = { summary = it },
                    label = { Text("ملخص ومقدمة الفصل") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text("المقطع / المبحث الأساسي:", fontWeight = FontWeight.Bold, color = EmeraldPrimaryDark)

                OutlinedTextField(
                    value = secTitle,
                    onValueChange = { secTitle = it },
                    label = { Text("عنوان المقطع") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = secParagraphsText,
                    onValueChange = { secParagraphsText = it },
                    label = { Text("نصوص وفقرات المقطع (افصل بين الفقرات بسطر فارغ)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )
                OutlinedTextField(
                    value = secQuotesText,
                    onValueChange = { secQuotesText = it },
                    label = { Text("الآيات والأحاديث (سطر لكل نص)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                OutlinedTextField(
                    value = secScience,
                    onValueChange = { secScience = it },
                    label = { Text("ملاحظة علمية أو عصبية (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = secKeyTakeaway,
                    onValueChange = { secKeyTakeaway = it },
                    label = { Text("خلاصة للعمل والهمة (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pList = secParagraphsText.split("\n\n").map { it.trim() }.filter { it.isNotBlank() }
                    val qList = secQuotesText.split("\n").map { it.trim() }.filter { it.isNotBlank() }

                    val updatedSection = ChapterSection(
                        id = firstSec?.id ?: "sec_${id}_1",
                        title = secTitle.ifBlank { "المبحث الأول" },
                        paragraphs = if (pList.isNotEmpty()) pList else listOf("نص المبحث..."),
                        quranOrHadith = qList,
                        scientificNote = secScience.ifBlank { null },
                        keyTakeaway = secKeyTakeaway.ifBlank { null }
                    )

                    val remainingSections = if (chapter.sections.size > 1) chapter.sections.drop(1) else emptyList()
                    val fullSections = listOf(updatedSection) + remainingSections

                    onSave(
                        BookChapter(
                            id = id,
                            numberTitle = numberTitle.ifBlank { "الفصل $id" },
                            title = title.ifBlank { "عنوان الفصل" },
                            subtitle = subtitle,
                            summary = summary,
                            sections = fullSections
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark)
            ) {
                Text("حفظ التغييرات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun AdminDailyPlansTab(
    plans: List<DailyJourneyPlan>,
    onEditPlan: (DailyJourneyPlan) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(plans) { plan ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = plan.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark
                        )
                        Text(
                            text = "الورد: ${plan.spiritualTask}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                    }

                    IconButton(onClick = { onEditPlan(plan) }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل الخطة", tint = EmeraldPrimaryDark)
                    }
                }
            }
        }
    }
}

@Composable
fun DailyPlanEditorDialog(
    plan: DailyJourneyPlan,
    onDismiss: () -> Unit,
    onSave: (DailyJourneyPlan) -> Unit
) {
    var title by remember { mutableStateOf(plan.title) }
    var habitFocus by remember { mutableStateOf(plan.habitFocus) }
    var spiritualTask by remember { mutableStateOf(plan.spiritualTask) }
    var practicalTask by remember { mutableStateOf(plan.practicalTask) }
    var quranOrHadith by remember { mutableStateOf(plan.quranVerseOrHadith) }
    var affirmation by remember { mutableStateOf(plan.dailyAffirmation) }
    var quote by remember { mutableStateOf(plan.motivationalQuote) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل خطة اليوم ${plan.dayNumber}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان اليوم") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = habitFocus,
                    onValueChange = { habitFocus = it },
                    label = { Text("العادة والتركيز") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = spiritualTask,
                    onValueChange = { spiritualTask = it },
                    label = { Text("الورد الروحي") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                OutlinedTextField(
                    value = practicalTask,
                    onValueChange = { practicalTask = it },
                    label = { Text("المهمة التطبيقية والسلوكية") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                OutlinedTextField(
                    value = quranOrHadith,
                    onValueChange = { quranOrHadith = it },
                    label = { Text("الدليل (آية أو حديث)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = affirmation,
                    onValueChange = { affirmation = it },
                    label = { Text("تأكيد العقل الباطن") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = quote,
                    onValueChange = { quote = it },
                    label = { Text("اقتباس تحفيزي") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        plan.copy(
                            title = title,
                            habitFocus = habitFocus,
                            spiritualTask = spiritualTask,
                            practicalTask = practicalTask,
                            quranVerseOrHadith = quranOrHadith,
                            dailyAffirmation = affirmation,
                            motivationalQuote = quote
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark)
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun AdminSecurityTab(
    currentPin: String,
    onUpdatePin: (String) -> Unit,
    onResetChapters: () -> Unit,
    onResetDailyPlans: () -> Unit
) {
    var newPin by remember { mutableStateOf("") }
    var showPinSuccess by remember { mutableStateOf(false) }
    var showResetChaptersDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = AmberSecondaryDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تغيير رمز PIN الخاص بالمشرف",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("الرمز الحالي: $currentPin", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newPin,
                        onValueChange = {
                            if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                newPin = it
                                showPinSuccess = false
                            }
                        },
                        label = { Text("الرمز السري الجديد (4 إلى 6 أرقام)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (showPinSuccess) {
                        Text(
                            text = "تم تحديث الرمز السري للمشرف بنجاح!",
                            color = EmeraldPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (newPin.length >= 4) {
                                onUpdatePin(newPin)
                                showPinSuccess = true
                                newPin = ""
                            }
                        },
                        enabled = newPin.length >= 4,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimaryDark),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تحديث رمز المشرف")
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "استعادة البيانات الأصلية للكتاب",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "إذا أردت استرجاع الفصول الافتراضية الأصلية لكتاب 'طريق التحرر' من ملف الـ JSON أو إعادة ضبط خطة الـ 40 يوماً الأصلية، يمكنك ذلك بضغطة زر.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showResetChaptersDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("استعادة فصول الكتاب الافتراضية")
                        }

                        Button(
                            onClick = onResetDailyPlans,
                            colors = ButtonDefaults.buttonColors(containerColor = AmberSecondaryDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("استعادة الـ 40 يوماً", color = Color.Black)
                        }
                    }
                }
            }
        }
    }

    if (showResetChaptersDialog) {
        AlertDialog(
            onDismissRequest = { showResetChaptersDialog = false },
            title = { Text("استعادة الفصول الافتراضية") },
            text = { Text("سيتم استبدال أي تعديلات أجريتها بفصول الكتاب الأصلية. هل تود المتابعة؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetChapters()
                        showResetChaptersDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، استعد الفصول")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetChaptersDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
