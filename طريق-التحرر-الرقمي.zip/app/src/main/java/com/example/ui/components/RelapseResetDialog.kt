package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberSecondaryDark

@Composable
fun RelapseResetDialog(
    onDismiss: () -> Unit,
    onConfirmReset: (String, String, String) -> Unit
) {
    val triggers = listOf(
        "خلوة بالهاتف ليلاً",
        "ملل وفراغ بدون عمل",
        "توتر وضغط نفسي/عمل",
        "تصفح عشوائي للسوشيال ميديا",
        "إرهاق شديد وقلة نوم",
        "مثير بصري عابر لم أقطعه فوراً"
    )

    var selectedTrigger by remember { mutableStateOf(triggers.first()) }
    var customFeelings by remember { mutableStateOf("ندم ورغبة صادقة في العودة إلى الله فوراً") }
    var lessonLearned by remember { mutableStateOf("شحن الهاتف خارج الغرفة والوضوء فور أي وسوسة") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = AmberSecondaryDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تسجيل كبوة وإعادة الانطلاق", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "« كل بني آدم خطاء، وخير الخطائين التوابون ». سقوطك لا يعني أنك فشلت، بل يعني أنك تقاتل. انهض فوراً وتعلّم من الثغرة!",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Text(
                    text = "ما السبب الرئيسي الذي أدى للانزلاق؟",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                triggers.forEach { t ->
                    val isSelected = selectedTrigger == t
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) AmberSecondaryDark.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickable { selectedTrigger = t }
                            .padding(10.dp)
                    ) {
                        Text(
                            text = t,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) AmberSecondaryDark else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                OutlinedTextField(
                    value = customFeelings,
                    onValueChange = { customFeelings = it },
                    label = { Text("المشاعر الحالية") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = lessonLearned,
                    onValueChange = { lessonLearned = it },
                    label = { Text("الدرس الحاسم لتفادي التكرار") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmReset(selectedTrigger, customFeelings, lessonLearned)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.testTag("confirm_reset_streak_button")
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصفير العداد والنهوض بعهد جديد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("تراجع")
            }
        }
    )
}
