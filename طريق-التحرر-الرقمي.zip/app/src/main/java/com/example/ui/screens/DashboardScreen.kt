package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ProfileEntity
import com.example.data.model.BadgesData
import com.example.data.model.UserStatus
import com.example.data.repository.BookRepository
import com.example.ui.components.StreakCard
import com.example.ui.theme.AmberSecondaryDark
import com.example.ui.theme.EmeraldContainerDark
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.RedEmergency

@Composable
fun DashboardScreen(
    profile: ProfileEntity,
    onOpenSos: () -> Unit,
    onNavigateToBook: (Int) -> Unit,
    onNavigateToFortyDays: () -> Unit,
    onNavigateToWithdrawal: () -> Unit,
    onNavigateToJournal: () -> Unit,
    onNavigateToGreatFigures: () -> Unit,
    onNavigateToDetox: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onLogVictory: () -> Unit,
    onResetStreak: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val streakDays = remember(profile.streakStartEpochMs) {
        val now = System.currentTimeMillis()
        ((now - profile.streakStartEpochMs).coerceAtLeast(0L) / (1000 * 60 * 60 * 24)).toInt()
    }

    val currentStatus = try {
        UserStatus.valueOf(profile.userStatus)
    } catch (_: Exception) {
        UserStatus.SINGLE
    }

    // Status personalized advice from book Chapter 3
    val statusAdvice = when (currentStatus) {
        UserStatus.ADOLESCENT -> Pair(
            "توجيه مخصص لسن المراهقة (الفصل الثالث):",
            "دماغك الآن في مرحلة تشكل ذهبي؛ القشرة الجبهية تُبنى يوماً بيوم. كل نظرة تمنعها تصنع رجولة ثابتة وذكاءً حاداً وتحصيلاً دراسياً متفوقاً."
        )
        UserStatus.SINGLE -> Pair(
            "توجيه مخصص للأعزب (الفصل السابع والتاسع):",
            "طاقتك الجنسية طاقة بناء وقيادة أودعها الله فيك لتصرفها في الرياضة، العمل، وتطوير المهارات. العفة تحفظ ماء وجهك وهيبتك ورزقك القادم."
        )
        UserStatus.MARRIED -> Pair(
            "توجيه مخصص للمتزوج (الفصل الثالث):",
            "الإباحية تشوه ميزان اللذة بمقارنات وهمية زائفة. زوجتك ودفء بيتك هما الحلال الصادق؛ طهر عينيك ليعود الشوق والحنان والمودة لسكنك."
        )
    }

    val randomQuote = remember {
        BookRepository.dailyQuotes.random()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top App Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    Text(
                        text = "مرحباً، ${profile.userName}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "طريق التحرر من عبودية الوهم",
                        style = MaterialTheme.typography.bodySmall,
                        color = EmeraldPrimaryDark,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Anti-Phone / Night Guard Quick Button
                Surface(
                    onClick = onNavigateToDetox,
                    shape = RoundedCornerShape(20.dp),
                    color = AmberSecondaryDark.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, AmberSecondaryDark.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("dashboard_detox_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "حارس الليل",
                            tint = AmberSecondaryDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "حارس الليل",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark
                        )
                    }
                }
            }
        }

        // SOS Emergency Button Banner (زر الطوارئ الفوري - بتصميم عصري ملفت وبطولي)
        item {
            SosEmergencyBanner(
                onOpenSos = onOpenSos
            )
        }

        // Hero Banner Image
        item {
            ElevatedCard(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToBook(0) }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.book_hero_banner),
                        contentDescription = "طريق التحرر - غلاف الكتاب",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color(0xCC0B1120))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "افهم عقلك • طهر قلبك • ابنِ مستقبلك",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberSecondaryDark
                        )
                        Text(
                            text = "رحلة التعافي تبدأ بقرار.. والنصر هو اختيارك",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Streak Live Counter Card
        item {
            StreakCard(
                streakStartEpochMs = profile.streakStartEpochMs,
                longestStreakDays = profile.longestStreakDays,
                totalRelapses = profile.totalRelapses,
                onLogVictory = onLogVictory,
                onResetStreak = onResetStreak
            )
        }

        // Personalized Status Guidance Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EmeraldPrimaryDark.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = statusAdvice.first,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimaryDark
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AmberSecondaryDark.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = currentStatus.titleAr,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberSecondaryDark
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = statusAdvice.second,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Quick Feature Grid (The Book, 40 Days, Withdrawal Guide, Journal, Great Figures)
        item {
            Text(
                text = "الأقسام والمحاور التفاعلية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FeatureCard(
                    title = "قراءة الكتاب كاملاً",
                    subtitle = "12 فصلاً مفصلاً",
                    icon = Icons.AutoMirrored.Filled.MenuBook,
                    accentColor = EmeraldPrimaryDark,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToBook(0) }
                )
                FeatureCard(
                    title = "برنامج الـ 40 يوماً",
                    subtitle = "العادات والورد اليومي",
                    icon = Icons.Default.CalendarMonth,
                    accentColor = AmberSecondaryDark,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToFortyDays
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FeatureCard(
                    title = "الأعراض الانسحابية",
                    subtitle = "دليل الأعراض الـ 10",
                    icon = Icons.Default.MedicalServices,
                    accentColor = Color(0xFF38BDF8),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToWithdrawal
                )
                FeatureCard(
                    title = "سجل الانتصارات",
                    subtitle = "التعثر والمشاعر",
                    icon = Icons.Default.EditNote,
                    accentColor = Color(0xFFA855F7),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToJournal
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FeatureCard(
                    title = "قصص العظماء",
                    subtitle = "10 أبطال قهروا الضعف",
                    icon = Icons.Default.People,
                    accentColor = Color(0xFFF97316),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToGreatFigures
                )
                FeatureCard(
                    title = "حارس الليل والانفصال",
                    subtitle = "تحدي الجوال والتأمل",
                    icon = Icons.Default.Shield,
                    accentColor = AmberSecondaryDark,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToDetox
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FeatureCard(
                    title = "الإعدادات والأمان",
                    subtitle = "رمز PIN والتنبيهات",
                    icon = Icons.Default.Settings,
                    accentColor = Color(0xFF64748B),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSettings
                )
            }
        }

        // Badges & Achievements Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "أوسمة وشارات الإنجاز",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "صمودك الحالي: $streakDays يوم",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(BadgesData.allBadges) { badge ->
                    val isUnlocked = streakDays >= badge.requiredDays
                    BadgeItemView(badge = badge, isUnlocked = isUnlocked)
                }
            }
        }

        // Daily Cutting Quote Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = null,
                                tint = AmberSecondaryDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "اقتباس اليوم لتغذية العقل الباطن",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = AmberSecondaryDark
                            )
                        }

                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(randomQuote))
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "نسخ الاقتباس",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = "« $randomQuote »",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun FeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .clickable { onClick() }
            .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun BadgeItemView(
    badge: com.example.data.model.RecoveryBadge,
    isUnlocked: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) EmeraldContainerDark.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(130.dp)
            .border(
                1.dp,
                if (isUnlocked) EmeraldPrimaryDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = badge.iconEmoji,
                fontSize = 28.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = badge.title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isUnlocked) AmberSecondaryDark else MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Text(
                text = "${badge.requiredDays} يوماً",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isUnlocked) EmeraldPrimaryDark.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (isUnlocked) "مكتمل ✓" else "قيد الإنجاز",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUnlocked) EmeraldPrimaryDark else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun SosEmergencyBanner(
    onOpenSos: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sos_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sos_pulse_alpha"
    )
    val beaconScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sos_beacon_scale"
    )

    Card(
        onClick = onOpenSos,
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_sos_button"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2B1013)
        ),
        border = BorderStroke(1.5.dp, RedEmergency.copy(alpha = pulseAlpha)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0x33DC2626),
                            Color(0x1ADC2626),
                            Color.Transparent
                        )
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Pulsing SOS Alert Beacon
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(46.dp)
                            .scale(beaconScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        RedEmergency,
                                        Color(0xFF991B1B)
                                    )
                                )
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "زر الطوارئ",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "زر الطوارئ الفوري (SOS)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = RedEmergency
                            ) {
                                Text(
                                    text = "تدخل عاجل",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "تشعر برغبة ملحة أو خطر انتكاس؟ اضغط هنا للنجاة فوراً",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFE2E8F0),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Prominent Call-to-Action Pill Button
                Button(
                    onClick = onOpenSos,
                    colors = ButtonDefaults.buttonColors(containerColor = RedEmergency),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "إنقاذ الآن",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}
